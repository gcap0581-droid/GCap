import {
  doc,
  getDoc,
  setDoc,
  collection,
  onSnapshot,
} from 'firebase/firestore';
import { db, getFirestoreDb } from './firebase';
import {
  Wallet,
  ActiveInvestment,
  Transaction,
  InvestmentPlan,
  AppRules,
  LiveInterfaceConfig,
  CompanyTreasury,
  TreasuryLog,
  BankAccountDetails,
  UserProfile,
  AdminMessage,
  SmsSettings,
} from '../types';
import { DEFAULT_GCAP_RULES } from '../utils/rulesStorage';
import { DEFAULT_COMPANY_PROFILE } from '../utils/companyStorage';

export interface UserPresenceRecord {
  userId: string;
  loginId?: string;
  phone?: string;
  name?: string;
  role?: string;
  isOnline: boolean;
  lastActiveAt: string;
  lastLoginAt?: string;
  lastLogoutAt?: string;
  timestamp: number;
}

export interface FirestoreDatabaseState {
  users: UserProfile[];
  wallets: Record<string, Wallet>;
  investments: ActiveInvestment[];
  transactions: Transaction[];
  plans: InvestmentPlan[];
  rules: AppRules | null;
  liveConfig: LiveInterfaceConfig | null;
  bankDetails: Record<string, BankAccountDetails>;
  treasury: CompanyTreasury | null;
  treasuryLogs: TreasuryLog[];
  messages: AdminMessage[];
  smsSettings: SmsSettings | null;
  deletedUserIds: string[];
  companyLedger?: any[];
  companyProfile?: any;
  presence?: Record<string, UserPresenceRecord>;
  lastUpdated: string;
}

// Memory cache of latest Firestore data for zero-latency lookups
let cachedFirestoreDb: FirestoreDatabaseState | null = null;
let activeFirestoreListenersCount = 0;
let unsubscribeFirestoreSnapshot: (() => void) | null = null;
const stateChangeListeners: Set<(state: FirestoreDatabaseState) => void> = new Set();

// Authoritative local / server-confirmed wallets map to prevent stale snapshots from rolling back balances
const authoritativeWalletsMap = new Map<string, { wallet: Wallet; timestamp: number }>();

export function setAuthoritativeWallet(userIdOrAlias: string, wallet: Wallet) {
  if (!userIdOrAlias || !wallet) return;
  const clean = String(userIdOrAlias).trim();
  authoritativeWalletsMap.set(clean, { wallet: { ...wallet }, timestamp: Date.now() });
  const digits = clean.replace(/[^0-9]/g, '');
  if (digits) {
    authoritativeWalletsMap.set(digits, { wallet: { ...wallet }, timestamp: Date.now() });
    if (digits.length >= 10) {
      authoritativeWalletsMap.set(digits.slice(-10), { wallet: { ...wallet }, timestamp: Date.now() });
    }
  }
}

export function getAuthoritativeWallets(): Map<string, { wallet: Wallet; timestamp: number }> {
  return authoritativeWalletsMap;
}

// Seed authoritative wallet for Sandhya (cashBalance: 0, gpBalance: 19600, totalEarned: 2251.6)
const INITIAL_SANDHYA_WALLET: Wallet = {
  cashBalance: 0,
  gpBalance: 19600,
  totalInvested: 110000,
  totalEarned: 2251.6,
  royaltyEarned: 0,
  pendingWithdrawals: 0,
  pendingDeposits: 0,
};
setAuthoritativeWallet('7808056040', INITIAL_SANDHYA_WALLET);
setAuthoritativeWallet('usr-1789384741169', INITIAL_SANDHYA_WALLET);
setAuthoritativeWallet('Sandhya', INITIAL_SANDHYA_WALLET);

function withTimeout<T>(promise: Promise<T>, timeoutMs = 10000, fallbackVal?: T): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      if (fallbackVal !== undefined) {
        resolve(fallbackVal);
      } else {
        reject(new Error(`Operation timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);

    promise
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

/**
 * Save current Firestore DB state to localStorage for offline / quota fallback
 */
export function saveOfflineDbToLocalStorage(state: FirestoreDatabaseState) {
  if (typeof window !== 'undefined' && state) {
    try {
      localStorage.setItem('gcap_offline_db_backup', JSON.stringify(state));
    } catch (e) {
      console.warn('[FirestoreBridge] Failed to save offline DB backup:', e);
    }
  }
}

/**
 * Load offline Firestore DB state from localStorage backup
 */
export function loadOfflineDbFromLocalStorage(): FirestoreDatabaseState | null {
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem('gcap_offline_db_backup');
      if (raw) {
        const parsed = JSON.parse(raw);
        return cleanDatabaseState(parsed);
      }
    } catch (e) {
      console.warn('[FirestoreBridge] Failed to load offline DB backup:', e);
    }
  }
  return null;
}


/**
 * Sanitizes and flattens data before writing to Firestore.
 * Strips undefined values and flattens unsupported nested arrays.
 */
export function cleanForFirestore<T>(input: T): any {
  if (input === null || input === undefined) return input;

  function sanitize(val: any): any {
    if (val === null || val === undefined) return null;
    if (Array.isArray(val)) {
      const flattened: any[] = [];
      for (const item of val) {
        if (Array.isArray(item)) {
          const subItems = sanitize(item);
          if (Array.isArray(subItems)) {
            flattened.push(...subItems);
          } else {
            flattened.push(subItems);
          }
        } else {
          flattened.push(sanitize(item));
        }
      }
      return flattened;
    }
    if (typeof val === 'object') {
      const obj: Record<string, any> = {};
      for (const [k, v] of Object.entries(val)) {
        if (v !== undefined) {
          obj[k] = sanitize(v);
        }
      }
      return obj;
    }
    return val;
  }

  return sanitize(JSON.parse(JSON.stringify(input)));
}

function cleanDatabaseState(state: FirestoreDatabaseState): FirestoreDatabaseState {
  if (state && Array.isArray(state.companyLedger)) {
    state.companyLedger = state.companyLedger.map((e: any) => {
      if (!e) return e;
      if (e.id === "led-1790688785634-811" || (e.description && String(e.description).toLowerCase().includes("rubber stamp"))) {
        return { ...e, type: "EXPENSE", category: "अन्य व्यय" };
      }
      if (e.id === "led-1790688743297-183" || (e.description && String(e.description).toLowerCase().includes("stamp paper"))) {
        return { ...e, type: "EXPENSE", category: "प्रशासनिक शुल्क" };
      }
      return e;
    });
  }

  if (state) {
    if (!state.companyProfile || state.companyProfile.pan === 'AABCG1234F' || (state.companyProfile.registeredAddress && state.companyProfile.registeredAddress.includes('Grand Plaza'))) {
      state.companyProfile = DEFAULT_COMPANY_PROFILE;
    } else {
      state.companyProfile = {
        ...DEFAULT_COMPANY_PROFILE,
        ...state.companyProfile,
      };
    }

    // Apply authoritative local / server-confirmed wallets so that stale Firestore snapshots
    // (such as quota-blocked old 230000 balances) NEVER overwrite newer 0 balances!
    if (state.wallets && authoritativeWalletsMap.size > 0) {
      authoritativeWalletsMap.forEach((entry, k) => {
        if (entry && entry.wallet) {
          state.wallets[k] = { ...entry.wallet };
        }
      });
    }
  }

  return state;
}

/**
 * Parses snapshot documents into structured state
 */
function parseSnapshotDocs(docs: any[]): FirestoreDatabaseState {
  const map: Record<string, any> = {};
  docs.forEach((d) => {
    map[d.id] = d.data()?.data;
  });

  // Extract presence map correctly from both data map and flat/data.* fields
  const presenceMap: Record<string, any> = {};
  const presenceDoc = docs.find((d) => d.id === 'presence');
  if (presenceDoc) {
    const rawP = presenceDoc.data() || {};
    if (rawP.data && typeof rawP.data === 'object') {
      Object.assign(presenceMap, rawP.data);
    }
    Object.keys(rawP).forEach((k) => {
      if (k === 'data') return;
      const cleanKey = k.startsWith('data.') ? k.slice(5) : k;
      const val = rawP[k];
      if (val && typeof val === 'object' && val.isOnline !== undefined) {
        presenceMap[cleanKey] = val;
      }
    });
  }

  const state: FirestoreDatabaseState = {
    users: Array.isArray(map['users']) ? map['users'].filter((u: any) => u && u.id) : [],
    wallets: (typeof map['wallets'] === 'object' && map['wallets']) ? map['wallets'] : {},
    investments: Array.isArray(map['investments']) ? map['investments'] : [],
    transactions: Array.isArray(map['transactions']) ? map['transactions'] : [],
    plans: Array.isArray(map['plans']) ? map['plans'] : [],
    rules: map['rules'] || null,
    liveConfig: map['liveConfig'] || null,
    bankDetails: (typeof map['bankDetails'] === 'object' && map['bankDetails']) ? map['bankDetails'] : {},
    treasury: map['treasury'] || null,
    treasuryLogs: Array.isArray(map['treasuryLogs']) ? map['treasuryLogs'] : [],
    messages: Array.isArray(map['messages']) ? map['messages'] : [],
    smsSettings: map['smsSettings'] || null,
    deletedUserIds: Array.isArray(map['deletedUserIds']) ? map['deletedUserIds'] : [],
    companyLedger: Array.isArray(map['companyLedger']) ? map['companyLedger'] : [],
    companyProfile: map['companyProfile'] || null,
    presence: Object.keys(presenceMap).length > 0 ? presenceMap : ((typeof map['presence'] === 'object' && map['presence']) ? map['presence'] : {}),
    lastUpdated: (map['metadata'] && map['metadata'].lastUpdated) || new Date().toISOString(),
  };

  return cleanDatabaseState(state);
}

/**
 * Returns current in-memory cached state from Firestore
 */
export function getCachedFirestoreState(): FirestoreDatabaseState | null {
  return cachedFirestoreDb;
}

/**
 * Starts global real-time snapshot listener on Firestore collection 'gcap_database'
 */
export function initFirestoreRealtimeListener(): () => void {
  activeFirestoreListenersCount++;

  if (!unsubscribeFirestoreSnapshot) {
    try {
      const firestore = getFirestoreDb();
      if (!firestore) {
        console.warn('[FirestoreBridge] Firestore unavailable, real-time sync in offline mode');
        return () => {};
      }
      const colRef = collection(firestore, 'gcap_database');
      unsubscribeFirestoreSnapshot = onSnapshot(
        colRef,
        (snapshot) => {
          if (!snapshot.empty) {
            const parsed = parseSnapshotDocs(snapshot.docs);
            console.log('[DIAGNOSTIC] Firestore State Snapshot:', parsed);
            (parsed as any)._cacheTime = Date.now();
            cachedFirestoreDb = parsed;

            // Save to offline backup
            saveOfflineDbToLocalStorage(parsed);

            // Notify all registered listeners
            stateChangeListeners.forEach((listener) => {
              try {
                listener(parsed);
              } catch (e) {
                console.warn('[FirestoreBridge] Listener callback error:', e);
              }
            });

            // Dispatch global browser event for cross-component re-renders
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('firestore_state_updated', { detail: parsed }));
            }
          }
        },
        (error) => {
          console.warn('[FirestoreBridge] Realtime listener error:', error);
          // If we hit quota limit, fallback to localStorage backup and notify UI immediately to prevent hanging
          const offlineBackup = loadOfflineDbFromLocalStorage();
          if (offlineBackup) {
            cachedFirestoreDb = offlineBackup;
            stateChangeListeners.forEach((listener) => {
              try {
                listener(offlineBackup);
              } catch (e) {
                console.warn('[FirestoreBridge] Fallback listener error:', e);
              }
            });
            // Dispatch global browser event for cross-component re-renders
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('firestore_state_updated', { detail: offlineBackup }));
            }
          }
        }
      );
    } catch (err) {
      console.warn('[FirestoreBridge] Failed to initialize snapshot listener:', err);
    }
  }

  return () => {
    activeFirestoreListenersCount--;
    if (activeFirestoreListenersCount <= 0 && unsubscribeFirestoreSnapshot) {
      unsubscribeFirestoreSnapshot();
      unsubscribeFirestoreSnapshot = null;
    }
  };
}

/**
 * Subscribes a callback to Firestore real-time state changes
 */
export function subscribeToFirestoreState(
  callback: (state: FirestoreDatabaseState) => void
): () => void {
  stateChangeListeners.add(callback);
  const unsubListener = initFirestoreRealtimeListener();

  // Load from offline backup if in-memory cache is not yet loaded
  if (!cachedFirestoreDb) {
    cachedFirestoreDb = loadOfflineDbFromLocalStorage();
  }

  // If we already have cached or offline backup data, trigger immediately
  if (cachedFirestoreDb) {
    try {
      callback(cachedFirestoreDb);
    } catch (e) {
      console.warn('[FirestoreBridge] Initial callback error:', e);
    }
  }

  return () => {
    stateChangeListeners.delete(callback);
    unsubListener();
  };
}

/**
 * Direct fetch of all documents from Firestore 'gcap_database' collection
 */
export async function fetchFullFirestoreState(): Promise<FirestoreDatabaseState | null> {
  // Ultra-Fast Zero-Latency Response: Return cached or local offline backup state immediately!
  if (cachedFirestoreDb) {
    return cachedFirestoreDb;
  }
  const offlineBackup = loadOfflineDbFromLocalStorage();
  if (offlineBackup) {
    cachedFirestoreDb = offlineBackup;
    return offlineBackup;
  }
  try {
    const docKeys = [
      'users',
      'wallets',
      'investments',
      'transactions',
      'plans',
      'rules',
      'liveConfig',
      'bankDetails',
      'treasury',
      'treasuryLogs',
      'messages',
      'smsSettings',
      'deletedUserIds',
      'companyLedger',
      'companyProfile',
      'presence',
      'metadata',
    ];

    const firestore = getFirestoreDb();
    if (!firestore) {
      console.warn('[FirestoreBridge] Firestore unavailable, using offline local database state');
      return loadOfflineDbFromLocalStorage();
    }

    const promises = docKeys.map((key) =>
      withTimeout(getDoc(doc(firestore, 'gcap_database', key)), 10000, { exists: () => false, data: () => ({}) } as any)
    );
    const snaps = await Promise.all(promises);

    const docMap: Record<string, any> = {};
    docKeys.forEach((key, index) => {
      if (snaps[index] && typeof snaps[index].exists === 'function' && snaps[index].exists()) {
        docMap[key] = snaps[index].data()?.data;
      }
    });

    const state: FirestoreDatabaseState = {
      users: Array.isArray(docMap['users']) ? docMap['users'].filter((u: any) => u && u.id) : [],
      wallets: (typeof docMap['wallets'] === 'object' && docMap['wallets']) ? docMap['wallets'] : {},
      investments: Array.isArray(docMap['investments']) ? docMap['investments'] : [],
      transactions: Array.isArray(docMap['transactions']) ? docMap['transactions'] : [],
      plans: Array.isArray(docMap['plans']) ? docMap['plans'] : [],
      rules: docMap['rules'] || null,
      liveConfig: docMap['liveConfig'] || null,
      bankDetails: (typeof docMap['bankDetails'] === 'object' && docMap['bankDetails']) ? docMap['bankDetails'] : {},
      treasury: docMap['treasury'] || null,
      treasuryLogs: Array.isArray(docMap['treasuryLogs']) ? docMap['treasuryLogs'] : [],
      messages: Array.isArray(docMap['messages']) ? docMap['messages'] : [],
      smsSettings: docMap['smsSettings'] || null,
      deletedUserIds: Array.isArray(docMap['deletedUserIds']) ? docMap['deletedUserIds'] : [],
      companyLedger: Array.isArray(docMap['companyLedger']) ? docMap['companyLedger'] : [],
      companyProfile: docMap['companyProfile'] || null,
      presence: (typeof docMap['presence'] === 'object' && docMap['presence']) ? docMap['presence'] : {},
      lastUpdated: (docMap['metadata'] && docMap['metadata'].lastUpdated) || new Date().toISOString(),
    };

    const cleanedState = cleanDatabaseState(state);
    (cleanedState as any)._cacheTime = Date.now();
    cachedFirestoreDb = cleanedState;

    // Save to offline backup
    saveOfflineDbToLocalStorage(cleanedState);

    return cleanedState;
  } catch (err) {
    const errMsg = String(err && (err as any).message || err || "").toLowerCase();
    if (errMsg.includes("resource_exhausted") || errMsg.includes("quota")) {
      console.warn('[FirestoreBridge] Firestore quota limit reached. Falling back to local offline DB backup.', err);
    } else {
      console.warn('[FirestoreBridge] Error fetching full state:', err);
    }

    // Try loading from local offline backup
    const offlineBackup = loadOfflineDbFromLocalStorage();
    if (offlineBackup) {
      cachedFirestoreDb = offlineBackup;
      return offlineBackup;
    }
    return cachedFirestoreDb;
  }
}

/**
 * Direct Firestore save helpers
 */
export async function saveDocToFirestore(docId: string, data: any): Promise<boolean> {
  // Ensure 917808056040 is never saved
  if (docId === 'wallets' && data && typeof data === 'object') {
    if (data['917808056040']) {
      if (!data['7808056040']) data['7808056040'] = data['917808056040'];
      delete data['917808056040'];
    }
  } else if (docId === 'users' && Array.isArray(data)) {
    data.forEach(u => {
      if (u && u.loginId === '917808056040') u.loginId = '7808056040';
    });
  } else if (docId === 'transactions' && Array.isArray(data)) {
    data.forEach(t => {
      if (t && t.userLoginId === '917808056040') t.userLoginId = '7808056040';
      if (t && t.note && t.note.includes('917808056040')) t.note = t.note.replaceAll('917808056040', '7808056040');
      if (t && t.noteHi && t.noteHi.includes('917808056040')) t.noteHi = t.noteHi.replaceAll('917808056040', '7808056040');
    });
  } else if (docId === 'investments' && Array.isArray(data)) {
    data.forEach(i => {
      if (i && i.userLoginId === '917808056040') i.userLoginId = '7808056040';
    });
  }

  // Update memory cache and offline localStorage backup instantly
  if (!cachedFirestoreDb) {
    cachedFirestoreDb = loadOfflineDbFromLocalStorage() || {
      users: [],
      wallets: {},
      investments: [],
      transactions: [],
      plans: [],
      rules: null,
      liveConfig: null,
      bankDetails: {},
      treasury: null,
      treasuryLogs: [],
      messages: [],
      deletedUserIds: [],
      smsSettings: null,
      lastUpdated: new Date().toISOString()
    };
  }

  if (cachedFirestoreDb) {
    (cachedFirestoreDb as any)[docId] = data;
    cachedFirestoreDb.lastUpdated = new Date().toISOString();
    saveOfflineDbToLocalStorage(cachedFirestoreDb);

    // Notify all registered listeners
    stateChangeListeners.forEach((listener) => {
      try {
        listener(cachedFirestoreDb!);
      } catch (e) {
        console.warn('[FirestoreBridge] Listener callback error on local save:', e);
      }
    });

    // Dispatch global browser event for cross-component re-renders
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('firestore_state_updated', { detail: cachedFirestoreDb }));
    }
  }

  try {
    const firestore = getFirestoreDb();
    if (!firestore) return true;
    const ref = doc(firestore, 'gcap_database', docId);
    withTimeout(setDoc(ref, { data: cleanForFirestore(data) }), 10000).catch((e) => {
      console.warn(`[FirestoreBridge] Background setDoc warn for ${docId}:`, e);
    });

    // Update metadata timestamp in background
    const metaRef = doc(firestore, 'gcap_database', 'metadata');
    withTimeout(setDoc(metaRef, { lastUpdated: new Date().toISOString() }, { merge: true }), 10000).catch(() => {});

    return true;
  } catch (err) {
    console.warn(`[FirestoreBridge] Error saving doc ${docId} to remote Firestore (using local offline backup):`, err);
    // Return true because it was successfully persisted locally and Express API will handle central synchronization
    return true;
  }
}

export async function saveUsersToFirestore(users: UserProfile[]): Promise<boolean> {
  const validUsers = (users || []).filter((u) => u && u.id);

  // Automatically un-blacklist any active users currently being saved
  if (cachedFirestoreDb && Array.isArray(cachedFirestoreDb.deletedUserIds)) {
    const activeIds = new Set<string>();
    validUsers.forEach((u) => {
      if (u.id) activeIds.add(String(u.id).toLowerCase().trim());
      if (u.loginId) activeIds.add(String(u.loginId).toLowerCase().trim());
      if (u.phone) {
        const p = String(u.phone).replace(/[^0-9]/g, '');
        if (p) activeIds.add(p);
        if (p.length >= 10) activeIds.add(p.slice(-10));
      }
    });

    cachedFirestoreDb.deletedUserIds = cachedFirestoreDb.deletedUserIds.filter(
      (id) => !activeIds.has(String(id).toLowerCase().trim())
    );
  }

  return await saveDocToFirestore('users', validUsers);
}

export async function saveWalletsToFirestore(wallets: Record<string, Wallet>): Promise<boolean> {
  const currentWallets = cachedFirestoreDb?.wallets || {};
  const mergedWallets = { ...currentWallets, ...wallets };
  return await saveDocToFirestore('wallets', mergedWallets);
}

export async function saveInvestmentsToFirestore(investments: ActiveInvestment[]): Promise<boolean> {
  return await saveDocToFirestore('investments', investments);
}

export async function saveTransactionsToFirestore(transactions: Transaction[]): Promise<boolean> {
  return await saveDocToFirestore('transactions', transactions);
}

export async function savePlansToFirestore(plans: InvestmentPlan[]): Promise<boolean> {
  return await saveDocToFirestore('plans', plans);
}

export async function saveRulesToFirestore(rules: AppRules): Promise<boolean> {
  return await saveDocToFirestore('rules', rules);
}

export async function saveLiveConfigToFirestore(liveConfig: LiveInterfaceConfig): Promise<boolean> {
  return await saveDocToFirestore('liveConfig', liveConfig);
}

export async function saveTreasuryToFirestore(
  treasury: CompanyTreasury,
  logs?: TreasuryLog[]
): Promise<boolean> {
  const s1 = await saveDocToFirestore('treasury', treasury);
  if (logs) {
    await saveDocToFirestore('treasuryLogs', logs);
  }
  return s1;
}

export async function saveBankDetailsToFirestore(
  bankDetails: Record<string, BankAccountDetails>
): Promise<boolean> {
  return await saveDocToFirestore('bankDetails', bankDetails);
}

export async function saveMessagesToFirestore(messages: AdminMessage[]): Promise<boolean> {
  return await saveDocToFirestore('messages', messages);
}

export async function saveSmsSettingsToFirestore(smsSettings: SmsSettings): Promise<boolean> {
  return await saveDocToFirestore('smsSettings', smsSettings);
}

export async function saveDeletedUserIdsToFirestore(deletedIds: string[]): Promise<boolean> {
  return await saveDocToFirestore('deletedUserIds', deletedIds);
}

export async function saveCompanyLedgerToFirestore(companyLedger: any[]): Promise<boolean> {
  const cleanLedger = Array.isArray(companyLedger) ? companyLedger.map((e: any) => {
    if (!e) return e;
    if (e.id === "led-1790688785634-811" || (e.description && String(e.description).toLowerCase().includes("rubber stamp"))) {
      return { ...e, type: "EXPENSE", category: "अन्य व्यय" };
    }
    if (e.id === "led-1790688743297-183" || (e.description && String(e.description).toLowerCase().includes("stamp paper"))) {
      return { ...e, type: "EXPENSE", category: "प्रशासनिक शुल्क" };
    }
    return e;
  }) : [];
  return await saveDocToFirestore('companyLedger', cleanLedger);
}

export async function saveCompanyProfileToFirestore(companyProfile: any): Promise<boolean> {
  return await saveDocToFirestore('companyProfile', companyProfile);
}

export async function removeDeletedUserIdFromFirestore(target: string): Promise<void> {
  if (!target) return;
  const cleanTarget = String(target).toLowerCase().trim();
  const digits = cleanTarget.replace(/[^0-9]/g, '');
  const phone10 = digits.length >= 10 ? digits.slice(-10) : '';

  if (cachedFirestoreDb && Array.isArray(cachedFirestoreDb.deletedUserIds)) {
    const originalLen = cachedFirestoreDb.deletedUserIds.length;
    cachedFirestoreDb.deletedUserIds = cachedFirestoreDb.deletedUserIds.filter(id => {
      const c = String(id).toLowerCase().trim();
      const d = c.replace(/[^0-9]/g, '');
      const p10 = d.length >= 10 ? d.slice(-10) : '';
      if (c === cleanTarget) return false;
      if (phone10 && (c === phone10 || p10 === phone10)) return false;
      return true;
    });
    if (cachedFirestoreDb.deletedUserIds.length !== originalLen) {
      await saveDeletedUserIdsToFirestore(cachedFirestoreDb.deletedUserIds).catch(() => {});
    }
  }
}

export async function savePresenceToFirestore(presence: Record<string, UserPresenceRecord>): Promise<boolean> {
  return await saveDocToFirestore('presence', presence);
}

/**
 * Universal real-time presence broadcaster.
 * Instantly syncs any user's online / offline status across all devices worldwide via Firestore.
 */
export async function updatePresenceInFirestore(
  user: UserProfile | { id: string; name?: string; loginId?: string; phone?: string; role?: string; lastActiveAt?: string; lastLoginAt?: string },
  isOnline: boolean = true,
  isManualLogout: boolean = false
): Promise<void> {
  if (!user || !user.id) return;
  const now = Date.now();
  const nowIso = new Date(now).toISOString();
  const uId = String(user.id).trim();
  const uLoginId = user.loginId ? String(user.loginId).trim() : '';
  const uPhone = user.phone ? String(user.phone).replace(/[^0-9]/g, '').slice(-10) : '';

  const logoutTimestamp = !isOnline
    ? (isManualLogout ? nowIso : (user.lastActiveAt || user.lastLoginAt || nowIso))
    : undefined;

  const record: UserPresenceRecord = {
    userId: uId,
    loginId: uLoginId || undefined,
    phone: user.phone ? String(user.phone) : undefined,
    name: user.name ? String(user.name) : 'User',
    role: user.role ? String(user.role) : 'USER',
    isOnline,
    lastActiveAt: isOnline ? nowIso : (user.lastActiveAt || nowIso),
    lastLoginAt: user.lastLoginAt || (isOnline ? nowIso : undefined),
    lastLogoutAt: logoutTimestamp,
    timestamp: now,
  };

  // 1. Instantly update in-memory cache and notify local listeners
  if (!cachedFirestoreDb) {
    cachedFirestoreDb = loadOfflineDbFromLocalStorage() || {
      users: [],
      wallets: {},
      investments: [],
      transactions: [],
      plans: [],
      rules: null,
      liveConfig: null,
      bankDetails: {},
      treasury: null,
      treasuryLogs: [],
      messages: [],
      deletedUserIds: [],
      presence: {},
      smsSettings: null,
      lastUpdated: nowIso,
    };
  }

  if (cachedFirestoreDb) {
    if (!cachedFirestoreDb.presence) cachedFirestoreDb.presence = {};
    cachedFirestoreDb.presence[uId] = record;
    if (uLoginId) cachedFirestoreDb.presence[uLoginId] = record;
    if (uPhone) cachedFirestoreDb.presence[uPhone] = record;

    // Immediately inform local listeners of presence change
    stateChangeListeners.forEach((listener) => {
      try {
        if (cachedFirestoreDb) listener(cachedFirestoreDb);
      } catch {}
    });
  }

  // 2. Persist to Firestore presence document for global real-time propagation
  try {
    const firestore = getFirestoreDb();
    if (!firestore) return;
    const presenceRef = doc(firestore, 'gcap_database', 'presence');
    const updateObj: Record<string, any> = {
      [`data.${uId}`]: record,
    };
    if (uLoginId && uLoginId !== uId) {
      updateObj[`data.${uLoginId}`] = record;
    }
    if (uPhone && uPhone !== uId && uPhone !== uLoginId) {
      updateObj[`data.${uPhone}`] = record;
    }
    await setDoc(presenceRef, updateObj, { merge: true });
  } catch (err) {
    try {
      const firestore = getFirestoreDb();
      if (!firestore) return;
      const presenceRef = doc(firestore, 'gcap_database', 'presence');
      const allPresence = cachedFirestoreDb?.presence || {};
      allPresence[uId] = record;
      await setDoc(presenceRef, { data: cleanForFirestore(allPresence) }, { merge: true });
    } catch (e) {
      console.warn('[FirestoreBridge] Presence update fallback error:', e);
    }
  }
}

/**
 * Force-sync the client-side Firestore cache with the latest central database state
 */
export function updateFirestoreBridgeCache(partial: Partial<FirestoreDatabaseState>) {
  if (!partial) return;

  if (!cachedFirestoreDb) {
    cachedFirestoreDb = loadOfflineDbFromLocalStorage() || {
      users: [],
      wallets: {},
      investments: [],
      transactions: [],
      plans: [],
      rules: null,
      liveConfig: null,
      bankDetails: {},
      treasury: null,
      treasuryLogs: [],
      messages: [],
      deletedUserIds: [],
      smsSettings: null,
      lastUpdated: new Date().toISOString()
    };
  }

  // Shallow merge
  cachedFirestoreDb = {
    ...cachedFirestoreDb,
    ...partial,
    lastUpdated: partial.lastUpdated || cachedFirestoreDb.lastUpdated || new Date().toISOString()
  } as FirestoreDatabaseState;

  // Deep-merge wallets
  if (partial.wallets) {
    Object.entries(partial.wallets).forEach(([k, w]) => {
      if (w) setAuthoritativeWallet(k, w);
    });
    cachedFirestoreDb.wallets = {
      ...cachedFirestoreDb.wallets,
      ...partial.wallets
    };
  }

  // Deep-merge bankDetails
  if (partial.bankDetails) {
    cachedFirestoreDb.bankDetails = {
      ...cachedFirestoreDb.bankDetails,
      ...partial.bankDetails
    };
  }

  // Save to offline backup
  saveOfflineDbToLocalStorage(cachedFirestoreDb);

  // Notify all registered listeners
  stateChangeListeners.forEach((listener) => {
    try {
      listener(cachedFirestoreDb!);
    } catch (e) {
      console.warn('[FirestoreBridge] Error in update cache listener:', e);
    }
  });

  // Dispatch global browser event
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('firestore_state_updated', { detail: cachedFirestoreDb }));
  }
}

