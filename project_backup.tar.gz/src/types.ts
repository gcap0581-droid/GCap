export type Language = 'en' | 'hi';

export type ViewMode = 'web' | 'android';

export interface Wallet {
  cashBalance: number; // Deposited INR balance (from company account transfer, approved by admin)
  gpBalance: number; // G-Points (GP) swapped from cashBalance (1 INR = 1 GP), used to purchase plans
  totalInvested: number;
  totalEarned: number; // Total Earning Amount (withdrawable 1st - 5th of month)
  royaltyEarned: number; // Total Royalty Earning Amount (withdrawable 6th - 10th of month)
  pendingWithdrawals: number;
  pendingDeposits: number; // Deposits waiting for admin approval (Wait for approval)
  totalWithdrawn?: number;
}

export type RiskLevel = 'Low' | 'Moderate' | 'High';

export interface InvestmentPlan {
  id: string;
  name: string;
  nameHi: string;
  dailyRoiPercent: number; // e.g. 1.8 means 1.8% daily
  durationDays: number;
  minAmount: number;
  maxAmount: number;
  payoutFrequency: 'Daily' | 'Hourly' | 'At Maturity';
  payoutFrequencyHi: string;
  risk: RiskLevel;
  tag: string;
  tagHi: string;
  badge?: string;
  description: string;
  descriptionHi: string;
  features: string[];
  featuresHi: string[];
}

export interface ActiveInvestment {
  id: string;
  userId?: string;
  userLoginId?: string;
  userName?: string;
  userPhone?: string;
  timestamp?: number;
  planUniqueId?: string; // Unique human-readable searchable plan ID (e.g., STP-641D-89421)
  planUniqueCode?: string;
  planId: string;
  planName: string;
  planNameHi?: string;
  investedAmount: number;
  dailyRoiPercent: number;
  dailyReturnAmount: number;
  totalExpectedReturn: number;
  earnedSoFar: number;
  totalEarnedSoFar?: number;
  claimedSoFar: number;
  totalWithdrawn?: number; // Total amount user has withdrawn from this investment
  unclaimedEarnings: number;
  startDate: string;
  endDate?: string;
  durationDays: number;
  daysCompleted?: number;
  lastPayoutTimestamp?: number;
  status: 'ACTIVE' | 'COMPLETED';
  autoReinvest?: boolean;
  createdAt?: number;
  cyclesCompleted?: number;
  // 641 Days Maturity and Renewal properties
  isMatured?: boolean; // True when 641 days are reached
  renewedCount?: number; // Times this plan ID has been renewed
  certificateIssued?: boolean; // Whether maturity certificate was generated
  certificateNumber?: string; // Unique certificate serial number
  // 24-Hour Initial Lock & 6-Hour Earning Cycle Properties
  activationTimestamp: number; // Timestamp when plan was started
  lockedUntilTimestamp: number; // 24 hours lock deadline (activationTimestamp + 24*3600*1000)
  isInitialLockCompleted: boolean; // True once 24 hours have elapsed
  lockCongratulationsShown?: boolean; // Whether 24h completion modal was displayed
  cycleDurationHours?: number; // 6 hours
  currentCycleStartTimestamp?: number; // Start timestamp of current 6h cycle
  currentCycleEndTimestamp?: number; // Target timestamp of current 6h cycle (start + 6*3600*1000)
  completedCyclesCount?: number; // Total number of 6h cycles completed
  cycleReturnAmount?: number; // Return amount per 6h cycle = 0.04% or 0.03% of invested amount
  // Long Term Plan & Royalty properties
  royaltyStage?: '365D_INITIAL' | '1461D_LOCK' | '1825D_ROYALTY' | 'COMPLETED';
  royaltyDaysCompleted?: number;
  principalWithdrawnAt1461D?: boolean;
  certificateType?: 'STP_641D' | 'LTP_365D' | 'LTP_ROYALTY_MASTER';
}

export type TransactionType =
  | 'DEPOSIT'
  | 'ADMIN_ADD'
  | 'SWAP_GP'
  | 'INVEST'
  | 'RETURN_PAYOUT'
  | 'WITHDRAWAL'
  | 'WITHDRAW'
  | 'ADMIN_DEDUCT'
  | 'CAPITAL_RETURN'
  | 'REFERRAL_BONUS'
  | 'TRANSFER';

export type WithdrawalSource = 'EARNING' | 'ROYALTY' | 'CASH';

export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'APPROVED' | 'APPROVED_PENDING_TRANSFER' | 'FAILED' | 'REJECTED';

export interface Transaction {
  id: string;
  userId?: string;
  userLoginId?: string;
  type: TransactionType;
  amount: number;
  date: string;
  timestamp: number;
  status: TransactionStatus;
  method?: string;
  referenceId: string;
  note: string;
  noteHi: string;
  actor?: string;
  withdrawalSource?: WithdrawalSource;
  gpEarned?: number;
  // Payment voucher breakdown fields
  grossAmount?: number;
  tdsPercent?: number;
  tdsAmount?: number;
  adminFeePercent?: number;
  adminFeeAmount?: number;
  netAmount?: number;
  destinationDetails?: string;
  userName?: string;
  userPhone?: string;
  panNumber?: string;
  rejectReason?: string;
  rejectReasonHi?: string;
}

export interface BankAccountDetails {
  accountHolder: string;
  accountNumber: string;
  ifscCode: string;
  bankName: string;
  upiId?: string;
}

export interface AppRules {
  platformName: string;
  adminTxPassword?: string;
  gpRatePerRupee?: number; // 1 Rupee = X GP (Default 1.0, e.g. 1 INR = 1 GP or 1 INR = 1.25 GP or 0.8 GP)
  minDeposit: number;
  maxDeposit: number;
  minWithdrawal: number;
  maxWithdrawalPerDay: number;
  withdrawalFeePercent: number;
  withdrawalTiming: string;
  withdrawalTimingHi: string;
  dailyPayoutCycle: string;
  dailyPayoutCycleHi: string;
  capitalReturnPolicy: '100%_AT_MATURITY' | 'AMORTIZED_DAILY';
  capitalReturnPolicyLabel: string;
  capitalReturnPolicyLabelHi: string;
  referralL1Percent: number;
  referralL2Percent: number;
  referralL3Percent?: number;
  isReferralEnabled?: boolean; // Toggle referral program on/off
  tdsPercent: number; // Government TDS percent (Default 5.0%)
  adminFeePercent?: number; // Admin charge percent on earnings withdrawal (Default 0.02%)
  shortTerm6hRate?: number; // 6-hour ROI for Short Term Plan
  longTerm6hRate?: number;  // 6-hour ROI for Long Term Plan
  supportEmail: string;
  supportPhone: string;
  adminWhatsAppNumber?: string;
  lastUpdated: string;
  companyUpiId?: string;
  companyBankAccountHolder?: string;
  companyBankName?: string;
  companyBankAccountNumber?: string;
  companyBankIfsc?: string;
  smsSettings?: SmsSettings;
}

export interface StaffPermissions {
  manageUsers: boolean;       // Create, edit, and view user profiles
  manageWallet: boolean;      // Adjust user balances (Add, deduct, set)
  manageTransactions: boolean;// Approve/Reject Deposits & Withdrawals
  manageSchemes: boolean;     // Add/edit plans & schemes
  manageTreasury: boolean;    // Manage company treasury and backups
  manageBroadcast: boolean;   // Send global broadcast and messages
  manageDeductions?: boolean; // View and export deductions & charges audit report
}

export type UserRole = 'ADMIN' | 'STAFF' | 'USER';

export interface UserProfile {
  id: string;
  loginId: string; // username, email or mobile
  name: string;
  role: UserRole;
  phone: string;
  email?: string;
  address?: string;
  password?: string;
  passwordHash?: string;
  referralCode?: string;
  referredBy?: string;
  joinedDate: string;
  status: 'ACTIVE' | 'BLOCKED' | 'SUSPENDED';
  suspendedReason?: string;
  suspendedReasonHi?: string;
  suspendedAt?: string;
  bankDetails?: BankAccountDetails;
  permissions?: StaffPermissions;
  dismissedPopupMsgIds?: string[];
  shownLockCongratsIds?: string[];
  isOnline?: boolean;
  lastLoginAt?: string;
  lastLogoutAt?: string;
  lastActiveAt?: string;
  device?: string;
  lastDevice?: string;
  // Real KYC Verification Details
  isPhoneVerified?: boolean;
  phoneVerifiedAt?: string;
  panNumber?: string;
  isPanVerified?: boolean;
  panVerifiedAt?: string;
  panHolderName?: string;
  aadhaarNumber?: string;
  isAadhaarVerified?: boolean;
  aadhaarVerifiedAt?: string;
  kycStatus?: 'NOT_SUBMITTED' | 'PENDING' | 'VERIFIED' | 'REJECTED';
}

export type TreasuryLogType =
  | 'ADMIN_ADD'
  | 'ADMIN_DEDUCT'
  | 'USER_INVESTMENT_DEDUCT'
  | 'USER_PAYOUT_DEDUCT'
  | 'USER_FUND_ADD_DEDUCT'
  | 'ADMIN_FEE_GP_COLLECT'
  | 'ADMIN_FEE_GP_CONVERT';

export interface TreasuryLog {
  id: string;
  type: TreasuryLogType;
  amount: number;
  balanceBefore: number;
  balanceAfter: number;
  date: string;
  timestamp: number;
  reason: string;
  reasonHi: string;
  actor: string;
  referenceId?: string;
}

export interface CompanyTreasury {
  balance: number;
  minAlertThreshold: number; // 500000 by requirement
  totalInjected: number;
  totalDeducted: number;
  totalTransferredToUsers: number;
  totalAdded?: number;
  collectedFeeGpBalance?: number; // Accumulated GP collected from transaction charges / admin fees
  totalFeeGpConverted?: number;   // Total Fee GP converted into Cash/Rupees
  lastUpdated: string;
}

export type BackupTriggerType = 'MIDNIGHT_AUTO' | 'ADMIN_MANUAL';

export interface CompanyProfile {
  companyName: string; // e.g. "GCAP PRIVATE LIMITED"
  companyNameHi?: string; // e.g. "जीकैप प्राइवेट लिमिटेड"
  tradeName?: string; // e.g. "GCAP PRIVATE LIMITED"
  cin?: string; // Corporate Identification Number e.g. "U66190BR2026OPC088307"
  pan?: string; // Company PAN e.g. "AANCG4365Q"
  tan?: string; // Tax Deduction TAN e.g. "PTNG16977C"
  gstin?: string; // GSTIN e.g. "10AANCG4365Q1Z5"
  incorporationDate?: string; // e.g. "2026-09-05"
  rocJurisdiction?: string; // e.g. "ROC Patna, Bihar"
  companyType?: string; // e.g. "Private Limited Company (Non-Govt Company)"
  authorizedCapital?: string; // e.g. "₹55,00,00,000"
  paidUpCapital?: string; // e.g. "₹1,00,00,000"
  registeredAddress?: string; // e.g. "Khari, Babhangawa, Shree Nagur, Near RRP School of Nursing Sasaram, Bihar - 821113"
  corporateAddress?: string; // e.g. "Khari, Babhangawa, Shree Nagur, Near RRP School of Nursing Sasaram, Bihar - 821113"
  city?: string; // e.g. "Sasaram"
  state?: string; // e.g. "Bihar"
  pincode?: string; // e.g. "821113"
  supportEmail?: string; // e.g. "support@gcapopc.com"
  legalEmail?: string; // e.g. "support@gcapopc.com"
  supportPhone?: string; // e.g. "+91 8503504808"
  altPhone?: string; // e.g. "+91 6184 220011"
  adminWhatsAppNumber?: string; // e.g. "+91 8603504808" for receiving instant deposit/withdrawal WhatsApp alerts
  websiteUrl?: string; // e.g. "https://www.gcapopc.com"
  authorizedSignatory?: string; // e.g. "Amit Kumar"
  signatoryDesignation?: string; // e.g. "Director & Authorized Signatory"
  signatoryDin?: string; // e.g. "DIN: 11964641"
  sealCity?: string; // e.g. "SASARAM (BIHAR)"
  bankName?: string; // e.g. "Axis Bank Ltd."
  bankAccountNumber?: string; // e.g. "924010008662307"
  bankIfsc?: string; // e.g. "UTIB0001219"
  bankBranch?: string; // e.g. "Axis Commercial Branch"
  bankAccountType?: string; // e.g. "Current Account"
  companyUpiId?: string; // e.g. "8603504808@axisbank"
  companyBankAccountHolder?: string; // e.g. "GCAP PRIVATE LIMITED"
  tagline?: string; // e.g. "ASSETS & WEALTH MANAGEMENT SYSTEM"
  taglineHi?: string; // e.g. "संपत्ति और धन प्रबंधन प्रणाली"
  // DPIIT Startup India Recognition (Govt of India)
  dippNumber?: string; // e.g. "DIPP285976"
  startupIndiaCertNumber?: string; // e.g. "DIPP285976"
  startupIndiaCertIssueDate?: string; // e.g. "30-09-2026"
  startupIndiaCertValidUpto?: string; // e.g. "22-09-2036"
  industry?: string; // e.g. "Finance Technology"
  sector?: string; // e.g. "Business Finance"
  dpiitMinistry?: string; // e.g. "Ministry of Commerce & Industry, DPIIT, Govt of India"
  lastUpdated?: string;
}

export interface BackupDataPayload {
  users: UserProfile[];
  wallet: Wallet;
  investments: ActiveInvestment[];
  transactions: Transaction[];
  plans: InvestmentPlan[];
  rules: AppRules;
  treasury: CompanyTreasury;
  treasuryLogs: TreasuryLog[];
  interfaceConfig?: LiveInterfaceConfig;
  companyProfile?: CompanyProfile;
}

export type ThemeAccent = 'emerald' | 'indigo' | 'amber' | 'cyan';

export type DesktopCategoryTab = 'dashboard' | 'plans' | 'investments' | 'wallet' | 'calculator' | 'rules';

export interface LiveInterfaceConfig {
  appVersion: string; // e.g. "v2.5.0-OTA"
  lastUpdated: string;
  themeAccent: ThemeAccent;
  bannerEnabled: boolean;
  bannerText: string;
  bannerTextHi: string;
  bannerType: 'info' | 'success' | 'alert';
  heroHeadline: string;
  heroHeadlineHi: string;
  heroSubtext: string;
  heroSubtextHi: string;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  maintenanceMessageHi: string;
  liveBadgeText: string;
  liveBadgeTextHi: string;
  autoSyncIntervalSec: number;
}

export type OtaUpdateType = 'RULES' | 'PLANS' | 'INTERFACE' | 'TREASURY' | 'SYSTEM';

export interface OtaEventPayload {
  id: string;
  type: OtaUpdateType;
  title: string;
  titleHi: string;
  description: string;
  descriptionHi: string;
  timestamp: number;
  version: string;
  updatedBy: string;
}

export interface BackupRecord {
  id: string;
  backupDate: string; // YYYY-MM-DD
  timestamp: number; // epoch ms
  triggerType: BackupTriggerType;
  title: string;
  titleHi: string;
  summary: {
    totalUsers: number;
    totalInvested: number;
    totalCashBalance: number;
    companyTreasuryBalance: number;
    activeInvestmentsCount: number;
    transactionsCount: number;
    plansCount: number;
  };
  payload: BackupDataPayload;
}

export type MessageTarget = 'ALL' | 'SINGLE' | 'INVESTORS' | 'POSITIVE_BALANCE' | 'SELECTED';
export type MessagePriority = 'NORMAL' | 'URGENT' | 'POPUP';
export type MessageCategory = 'ANNOUNCEMENT' | 'ALERT' | 'INFO' | 'BONUS' | 'SYSTEM';

export interface AdminMessage {
  id: string;
  title: string;
  titleHi?: string;
  content: string;
  contentHi?: string;
  senderName: string;
  targetType: MessageTarget;
  targetUserId?: string; // Single user ID or loginId
  targetUserLoginId?: string;
  targetUserName?: string;
  targetUserIds?: string[]; // Selected user IDs
  priority: MessagePriority;
  category: MessageCategory;
  showPopup: boolean; // Triggers instant modal on user screen
  showAsPopup?: boolean;
  type?: string;
  createdAt: string; // ISO / display string
  timestamp: number;
  expiresAt?: string;
  actionLabel?: string;
  actionUrl?: string;
  readByUserIds?: string[]; // user IDs who have read the message
  dismissedByUserIds?: string[]; // user IDs who dismissed the popup
}

export type WhatsAppAlertType =
  | 'DEPOSIT_ALERT'
  | 'WITHDRAWAL_ALERT'
  | 'PAYMENT_VOUCHER'
  | 'MATURITY_CERTIFICATE'
  | 'BROADCAST_NOTICE'
  | 'SECURITY_ALERT'
  | 'ROYALTY_REWARD'
  | 'CUSTOM_TEST';

export interface WhatsAppDispatchLog {
  id: string;
  type: WhatsAppAlertType;
  title: string;
  recipientPhone: string;
  recipientName?: string;
  recipientRole?: 'ADMIN' | 'INVESTOR' | 'USER';
  messageBody: string;
  timestamp: number;
  dateStr: string;
  status: 'DISPATCHED' | 'TEST_SAMPLE';
  referenceId?: string;
  amount?: number;
}

export interface MetaCloudApiConfig {
  enabled: boolean;
  phoneNumberId: string;
  wabaId: string;
  accessToken: string;
  verifiedDisplayName?: string; // e.g. "GCAP PRIVATE LIMITED"
}

export interface SmsTemplateConfig {
  enabled: boolean;
  template: string;
}

export interface SmsSettings {
  isSmsEnabled: boolean;
  senderId: string;
  sendOtpSms: SmsTemplateConfig;
  sendRegistrationSms: SmsTemplateConfig;
  sendDepositApprovalSms: SmsTemplateConfig;
  sendWithdrawalApprovalSms: SmsTemplateConfig;
  sendInvestmentSuccessSms: SmsTemplateConfig;
  sendRoiPayoutSms: SmsTemplateConfig;
  lastUpdated: string;
}


