import {
  Wallet,
  ActiveInvestment,
  Transaction,
  InvestmentPlan,
  AppRules,
  LiveInterfaceConfig,
  CompanyTreasury,
  TreasuryLog,
  BankAccountDetails,
  UserProfile,
  AdminMessage,
  CompanyProfile,
  UserRole,
} from '../types';
import { normalizeInvestmentsList, getStoredInvestments, getStoredTransactions, computeAuthoritativeWallet } from './storage';
import { apiFetch, isDirectServerHost } from './apiConfig';
import { recordDeletedUserId, isUserDeleted } from './authStorage';
import {
  fetchFullFirestoreState,
  getCachedFirestoreState,
  saveTransactionsToFirestore,
  saveInvestmentsToFirestore,
  saveWalletsToFirestore,
  savePlansToFirestore,
  saveRulesToFirestore,
  saveLiveConfigToFirestore,
  saveTreasuryToFirestore,
  saveBankDetailsToFirestore,
  saveMessagesToFirestore,
  updateFirestoreBridgeCache,
  FirestoreDatabaseState,
} from '../lib/firestoreBridge';

// Helper to retrieve current active user session directly from localStorage safely
function getLocalCurrentUser(): UserProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem('gcap_active_session_v1');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

// Helper to resolve user from multiple identifiers and generate all alias keys
export function findUserAndAllAliases(userId: string, users: UserProfile[]): { user: UserProfile | null, aliases: string[] } {
  const cleanId = String(userId || '').trim();
  const cleanDigits = cleanId.replace(/[^0-9]/g, "");
  const last10 = cleanDigits.slice(-10);

  // Combine provided users with the active session user to guarantee correct link even if users list is empty
  const activeUser = getLocalCurrentUser();
  const combinedUsers = [...(users || [])];
  if (activeUser && activeUser.id) {
    if (!combinedUsers.some(u => u.id === activeUser.id)) {
      combinedUsers.push(activeUser);
    }
  }

  const user = combinedUsers.find(
    (u) =>
      (u.id && u.id === cleanId) ||
      (u.loginId && u.loginId.toLowerCase() === cleanId.toLowerCase()) ||
      (cleanDigits && u.phone && u.phone.replace(/[^0-9]/g, "") === cleanDigits) ||
      (last10 && u.phone && u.phone.replace(/[^0-9]/g, "").slice(-10) === last10)
  );

  const aliases = new Set<string>();
  if (cleanId) aliases.add(cleanId);
  if (cleanDigits) aliases.add(cleanDigits);
  if (last10) aliases.add(last10);

  if (user) {
    if (user.id) {
      aliases.add(user.id);
      if (user.id.startsWith("usr-")) {
        aliases.add(user.id.replace("usr-", ""));
      }
    }
    if (user.loginId) aliases.add(user.loginId);
    if (user.phone) {
      const cleanP = user.phone.replace(/[^0-9]/g, "");
      if (cleanP) aliases.add(cleanP);
      if (cleanP.length >= 10) aliases.add(cleanP.slice(-10));
    }
  }

  // Explicitly purge 917808056040 and preserve 7808056040
  aliases.delete('917808056040');

  return { user: user || null, aliases: Array.from(aliases).filter(a => Boolean(a) && a !== '917808056040') };
}

// Helper to get a user's wallet with robust alias lookup and live authoritative reconciliation
export function getWalletForUser(userId: string, wallets: Record<string, Wallet>, users: UserProfile[]): Wallet {
  const { user } = findUserAndAllAliases(userId, users);
  const targetId = user?.id || user?.loginId || user?.phone || userId;
  return computeAuthoritativeWallet(targetId, user);
}

// Helper to get all active/completed investments for a specific user using robust alias resolution
export function getUserInvestments(
  userOrId: string | UserProfile,
  investments: ActiveInvestment[] = [],
  users: UserProfile[] = []
): ActiveInvestment[] {
  const sourceList = (Array.isArray(investments) && investments.length > 0)
    ? investments
    : (typeof window !== 'undefined' ? normalizeInvestmentsList(getStoredInvestments()) : []);
  if (!Array.isArray(sourceList) || sourceList.length === 0) return [];

  let userId = '';
  let uLogin = '';
  let uPhone = '';

  if (typeof userOrId === 'object' && userOrId !== null) {
    userId = String(userOrId.id || '').toLowerCase().trim();
    uLogin = String(userOrId.loginId || '').toLowerCase().trim();
    uPhone = String(userOrId.phone || '').trim();
  } else {
    userId = String(userOrId || '').toLowerCase().trim();
    const found = (users || []).find((u) => u && (u.id === userId || u.loginId === userId || (u.phone && u.phone.includes(userId))));
    if (found) {
      if (!userId) userId = String(found.id || '').toLowerCase().trim();
      uLogin = String(found.loginId || '').toLowerCase().trim();
      uPhone = String(found.phone || '').trim();
    }
  }

  const cleanDigits = userId.replace(/[^0-9]/g, '');
  const uPhoneDigits = uPhone.replace(/[^0-9]/g, '');
  const phone10 = (uPhoneDigits.length >= 10 ? uPhoneDigits.slice(-10) : uPhoneDigits) ||
                  (cleanDigits.length >= 10 ? cleanDigits.slice(-10) : cleanDigits);

  const matched = sourceList.filter((inv) => {
    if (!inv) return false;
    const invUserId = String(inv.userId || '').toLowerCase().trim();
    const invLoginId = String(inv.userLoginId || '').toLowerCase().trim();
    const invPhone = String(inv.userPhone || '').replace(/[^0-9]/g, '');
    const invPhone10 = invPhone.length >= 10 ? invPhone.slice(-10) : invPhone;

    // Direct id match
    if (userId && invUserId && (invUserId === userId || invUserId.includes(userId) || userId.includes(invUserId))) return true;
    // Login ID match
    if (uLogin && invLoginId && invLoginId === uLogin) return true;
    if (userId && invLoginId && invLoginId === userId) return true;
    // Phone match
    if (phone10 && invPhone10 && invPhone10 === phone10) return true;
    if (phone10 && (invUserId.includes(phone10) || invLoginId.includes(phone10))) return true;

    return false;
  });

  // Deduplicate by inv.id to prevent duplicate plans showing up for any user
  const uniqueMap = new Map<string, ActiveInvestment>();
  for (const inv of matched) {
    if (inv && inv.id) uniqueMap.set(inv.id, inv);
  }
  return Array.from(uniqueMap.values());
}

// Helper to update a user's wallet across all aliases in the map
export function updateWalletForUserInMap(userId: string, wallets: Record<string, Wallet>, users: UserProfile[], updatedWallet: Wallet): Record<string, Wallet> {
  const { user, aliases } = findUserAndAllAliases(userId, users);
  const updated = { ...wallets };
  const keysToUpdate = new Set<string>(aliases);

  const cleanId = String(userId || '').trim().replace(/[^0-9a-zA-Z]/g, '').toLowerCase();
  const phoneDigits = user?.phone ? user.phone.replace(/[^0-9]/g, '') : '';
  const phone10 = phoneDigits.slice(-10);

  for (const key of Object.keys(wallets)) {
    const cleanKey = key.replace(/[^0-9a-zA-Z]/g, '').toLowerCase();
    if (
      (cleanId && (cleanKey === cleanId || cleanKey.endsWith(cleanId) || cleanId.endsWith(cleanKey))) ||
      (phone10 && phone10.length >= 6 && cleanKey.includes(phone10)) ||
      (phoneDigits && phoneDigits.length >= 6 && cleanKey.includes(phoneDigits))
    ) {
      keysToUpdate.add(key);
    }
  }

  keysToUpdate.forEach((k) => {
    if (k) {
      updated[k] = { ...updatedWallet };
    }
  });

  return updated;
}

export interface CentralStateResponse {
  success: boolean;
  user?: UserProfile;
  users?: UserProfile[];
  transactions: Transaction[];
  investments: ActiveInvestment[];
  wallet?: Wallet;
  wallets?: Record<string, Wallet>;
  plans?: InvestmentPlan[];
  rules?: AppRules;
  liveConfig?: LiveInterfaceConfig;
  treasury?: CompanyTreasury;
  treasuryLogs?: TreasuryLog[];
  bankDetails?: BankAccountDetails | Record<string, BankAccountDetails> | null;
  companyProfile?: CompanyProfile;
  messages?: AdminMessage[];
  lastUpdated: string;
  serverTime?: number;
}

const API_BASE = '/api';

export function formatDatabaseToCentralResponse(
  fs: any,
  userId?: string,
  role: UserRole = 'USER'
): CentralStateResponse | null {
  if (!fs) return null;

  if (role === 'ADMIN') {
    return {
      success: true,
      users: (fs.users || []).filter((u: any) => u && u.id),
      transactions: fs.transactions || [],
      investments: fs.investments || [],
      wallets: fs.wallets || {},
      plans: fs.plans || [],
      rules: fs.rules || undefined,
      liveConfig: fs.liveConfig || undefined,
      treasury: fs.treasury || undefined,
      treasuryLogs: fs.treasuryLogs || [],
      bankDetails: fs.bankDetails || {},
      companyProfile: fs.companyProfile || undefined,
      messages: fs.messages || [],
      lastUpdated: fs.lastUpdated,
      serverTime: Date.now(),
    };
  } else {
    const { user: foundUser, aliases } = userId
      ? findUserAndAllAliases(userId, fs.users || [])
      : { user: null, aliases: [] };

    const userTxns = (fs.transactions || []).filter((t: any) => {
      if (!t) return false;
      const cleanReq = String(userId || '').toLowerCase().trim();
      const reqDigitsStr = cleanReq.replace(/[^0-9]/g, "");
      const req10 = reqDigitsStr.length >= 10 ? reqDigitsStr.slice(-10) : reqDigitsStr;

      const tUserId = (t.userId || "").toLowerCase().trim();
      const tUserLoginId = (t.userLoginId || "").toLowerCase().trim();
      const tUserPhone = (t.userPhone || "").replace(/[^0-9]/g, "");
      const tPhone10 = tUserPhone.length >= 10 ? tUserPhone.slice(-10) : tUserPhone;
      const tNote = ((t.note || "") + " " + (t.noteHi || "")).toLowerCase();

      const aliasMatch = aliases.some((a) => {
        if (!a) return false;
        const cleanA = a.toLowerCase().trim();
        return tUserId === cleanA || tUserLoginId === cleanA;
      });

      const isDirectMatch =
        aliasMatch ||
        tUserId === cleanReq ||
        tUserLoginId === cleanReq ||
        (req10 && tPhone10 === req10);

      const isNoteMatch =
        Boolean(cleanReq && cleanReq.length >= 4 && tNote.includes(cleanReq)) ||
        Boolean(req10 && req10.length >= 6 && tNote.includes(req10));

      return isDirectMatch || isNoteMatch;
    });
    const userInvestments = normalizeInvestmentsList(
      (fs.investments || []).filter((i: any) => {
        if (!i) return false;
        const iUserId = (i.userId || "").toLowerCase().trim();
        const iUserLoginId = (i.userLoginId || "").toLowerCase().trim();
        const iPhone = (i.userPhone || "").replace(/[^0-9]/g, "");
        const iPhone10 = iPhone.length >= 10 ? iPhone.slice(-10) : iPhone;

        return aliases.some((a) => {
          if (!a) return false;
          const cleanA = a.toLowerCase().trim();
          const clean10 = cleanA.replace(/[^0-9]/g, "").slice(-10);
          return (
            iUserId === cleanA ||
            iUserLoginId === cleanA ||
            (clean10 && clean10.length >= 6 && iPhone10 === clean10) ||
            iUserId.includes(cleanA)
          );
        }) || !i.userId;
      })
    );
    const userWallet = userId ? getWalletForUser(userId, fs.wallets || {}, fs.users || []) : {
      cashBalance: 0,
      gpBalance: 0,
      totalInvested: 0,
      totalEarned: 0,
      royaltyEarned: 0,
      pendingWithdrawals: 0,
      pendingDeposits: 0,
      totalWithdrawn: 0,
    };
    const userBank = (userId && fs.bankDetails && fs.bankDetails[userId]) || null;
    const { aliases: msgAliases } = userId
      ? findUserAndAllAliases(userId, fs.users || [])
      : { aliases: [] };
    const lowerAliases = msgAliases.map((a) => a.toLowerCase());

    const hasInvestmentsForMsg = (fs.investments || []).some((inv: any) => {
      if (inv.status !== 'ACTIVE') return false;
      const iUid = (inv.userId || '').toLowerCase();
      return lowerAliases.includes(iUid);
    });

    const userWalletForMsg = userId ? getWalletForUser(userId, fs.wallets || {}, fs.users || []) : null;
    const hasPositiveBalanceForMsg = userWalletForMsg
      ? (userWalletForMsg.cashBalance || 0) > 0 || (userWalletForMsg.gpBalance || 0) > 0
      : false;

    const userMsgs = (fs.messages || []).filter((m: any) => {
      if (!m) return false;
      if (m.targetType === 'ALL' || !m.targetType || m.targetUserId === 'ALL') return true;
      if (m.targetType === 'SINGLE') {
        const tId = (m.targetUserId || '').toLowerCase();
        const tLogin = (m.targetUserLoginId || '').toLowerCase();
        return lowerAliases.includes(tId) || lowerAliases.includes(tLogin);
      }
      if (m.targetType === 'INVESTORS') return hasInvestmentsForMsg;
      if (m.targetType === 'POSITIVE_BALANCE') return hasPositiveBalanceForMsg;
      if (m.targetType === 'SELECTED') {
        if (!Array.isArray(m.targetUserIds)) return false;
        const selectedList = m.targetUserIds.map((id: any) => String(id).toLowerCase());
        return lowerAliases.some((alias) => selectedList.includes(alias));
      }
      return false;
    });

    return {
      success: true,
      transactions: userTxns,
      investments: userInvestments,
      wallet: userWallet,
      plans: fs.plans || [],
      rules: fs.rules || undefined,
      liveConfig: fs.liveConfig || undefined,
      bankDetails: userBank,
      companyProfile: fs.companyProfile || undefined,
      messages: userMsgs,
      lastUpdated: fs.lastUpdated,
      serverTime: Date.now(),
    };
  }
}

/**
 * Fetch the latest real-time central database state.
 * If user is ADMIN, receives global platform state (all txns, all investments, all users, treasury).
 * If user is regular USER, receives user's transactions, investments, wallet, bank details, plus active plans & rules.
 */
export async function fetchCentralState(
  userId?: string,
  role: UserRole = 'USER'
): Promise<CentralStateResponse | null> {
  // 0. Instant Cache Check for Sub-second UI Load on Vercel
  const cached = getCachedFirestoreState();

  // 1. Try Express Central API (with fast timeout)
  try {
    const params = new URLSearchParams();
    if (userId) params.append('userId', userId);
    params.append('role', role);
    params.append('t', Date.now().toString());

    const res = await apiFetch(`${API_BASE}/central/state?${params.toString()}`, {
      headers: {
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache',
      },
    });

    if (res.ok) {
      const data: CentralStateResponse = await res.json().catch(() => null);
      if (data && data.success) {
        if (Array.isArray((data as any).deletedUserIds)) {
          (data as any).deletedUserIds.forEach((id: string) => recordDeletedUserId(id));
        }
        if (data.users && Array.isArray(data.users)) {
          data.users = data.users.filter((u: any) => u && u.id && !isUserDeleted(u));
        }

        // Sync to client-side FirestoreBridge cache
        if (role === 'ADMIN') {
          updateFirestoreBridgeCache({
            users: data.users || [],
            wallets: data.wallets || {},
            investments: data.investments || [],
            transactions: data.transactions || [],
            plans: data.plans || [],
            rules: data.rules || null,
            liveConfig: data.liveConfig || null,
            bankDetails: (data.bankDetails as Record<string, BankAccountDetails>) || {},
            treasury: data.treasury || null,
            treasuryLogs: data.treasuryLogs || [],
            messages: data.messages || [],
            lastUpdated: data.lastUpdated || new Date().toISOString(),
          });
        } else if (userId) {
          const { aliases } = findUserAndAllAliases(userId, []);
          const walletsMap: Record<string, Wallet> = {};
          if (data.wallet) {
            aliases.forEach(alias => {
              if (alias) walletsMap[alias] = data.wallet!;
            });
          }

          updateFirestoreBridgeCache({
            transactions: data.transactions || [],
            investments: data.investments || [],
            wallets: walletsMap,
            bankDetails: data.bankDetails ? { [userId]: data.bankDetails as BankAccountDetails } : {},
            plans: data.plans || [],
            rules: data.rules || null,
            liveConfig: data.liveConfig || null,
            messages: data.messages || [],
            lastUpdated: data.lastUpdated || new Date().toISOString(),
          });
        }

        return data;
      }
    }
  } catch (err) {
    console.warn('[CentralSync] API fetch failed, trying Firestore fallback...', err);
  }

  // 2. Direct Firestore State (Instant fallback for Vercel)
  if (cached) {
    const formatted = formatDatabaseToCentralResponse(cached, userId, role);
    if (formatted) return formatted;
  }

  try {
    const fs = await fetchFullFirestoreState();
    if (fs) return formatDatabaseToCentralResponse(fs, userId, role);
  } catch (fsErr) {
    console.warn('[CentralSync] Firestore fallback failed:', fsErr);
  }

  return null;
}

/**
 * Post a new transaction (Deposit / Withdrawal / Investment / GP Swap) to central database
 */
export async function apiCreateTransaction(
  transaction: Transaction,
  userId: string,
  wallet?: Wallet
): Promise<{ success: boolean; transaction?: Transaction; wallet?: Wallet; error?: string }> {
  // 1. Instantly append transaction & wallet to local memory cache & localStorage so zero-latency reads contain it
  try {
    const { aliases } = findUserAndAllAliases(userId, []);
    const walletsMap: Record<string, Wallet> = {};
    if (wallet) {
      aliases.forEach(alias => {
        if (alias) walletsMap[alias] = wallet;
      });
    }
    const fs = await fetchFullFirestoreState();
    if (fs) {
      const currentTxns = fs.transactions || [];
      const map = new Map<string, Transaction>();
      const key = transaction.id || transaction.referenceId;
      if (key) map.set(key, transaction);
      currentTxns.forEach((t) => {
        if (t) {
          const k = t.id || t.referenceId;
          if (k && !map.has(k)) map.set(k, t);
        }
      });
      const merged = Array.from(map.values()).sort((a, b) => {
        const timeA = a.timestamp || (a.date ? new Date(a.date).getTime() : 0);
        const timeB = b.timestamp || (b.date ? new Date(b.date).getTime() : 0);
        return timeB - timeA;
      });
      updateFirestoreBridgeCache({
        transactions: merged,
        ...(wallet ? { wallets: walletsMap } : {}),
      });
      saveTransactionsToFirestore(merged).catch(() => {});
    }
  } catch (e) {
    console.warn('[apiCreateTransaction] Early cache sync note:', e);
  }

  try {
    const res = await apiFetch(`${API_BASE}/transactions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transaction, userId, wallet }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (result.wallet) {
          const { aliases } = findUserAndAllAliases(userId, []);
          const walletsMap: Record<string, Wallet> = {};
          aliases.forEach(alias => {
            if (alias) walletsMap[alias] = result.wallet;
          });
          updateFirestoreBridgeCache({
            wallets: walletsMap,
          });
        }
        return result;
      }
    }
  } catch (err: any) {
    console.warn('[apiCreateTransaction] API fetch failed, using direct Firestore:', err);
  }

  // Direct Firestore write for Vercel
  try {
    const fs = await fetchFullFirestoreState();
    const currentTxns = fs?.transactions || [];
    const currentWallets = fs?.wallets || {};
    const existingWallet: Wallet = getWalletForUser(userId, currentWallets, fs?.users || []);
    let userWallet: Wallet = wallet ? { ...existingWallet, ...wallet } : { ...existingWallet };

    const newTxn: Transaction = {
      ...transaction,
      id: transaction.id || `txn-${Date.now()}`,
      userId,
      timestamp: transaction.timestamp || Date.now(),
      date: transaction.date || new Date().toISOString().split('T')[0],
    };

    if (!wallet) {
      if (newTxn.type === 'SWAP_GP') {
        const swapAmt = Number(newTxn.amount || 0);
        const gpEarned = Number(newTxn.gpEarned || swapAmt);
        userWallet.cashBalance = Math.max(0, (userWallet.cashBalance || 0) - swapAmt);
        userWallet.gpBalance = (userWallet.gpBalance || 0) + gpEarned;
      } else if (newTxn.type === 'DEPOSIT') {
        userWallet.pendingDeposits = (userWallet.pendingDeposits || 0) + newTxn.amount;
      } else if (newTxn.type === 'WITHDRAWAL') {
        userWallet.pendingWithdrawals = (userWallet.pendingWithdrawals || 0) + newTxn.amount;
      }
    }

    const updatedTxns = [newTxn, ...currentTxns.filter((t) => t.id !== newTxn.id)];
    const updatedWallets = updateWalletForUserInMap(userId, currentWallets, fs?.users || [], userWallet);

    await saveTransactionsToFirestore(updatedTxns);
    await saveWalletsToFirestore(updatedWallets);

    const { aliases } = findUserAndAllAliases(userId, fs?.users || []);
    const walletsMap: Record<string, Wallet> = {};
    aliases.forEach(alias => {
      if (alias) walletsMap[alias] = userWallet;
    });
    updateFirestoreBridgeCache({
      wallets: walletsMap,
    });

    return { success: true, transaction: newTxn, wallet: userWallet };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message || 'Firestore write failed' };
  }
}

/**
 * Admin updates transaction status (e.g. APPROVE / REJECT deposit or withdrawal)
 */
export async function apiUpdateTransaction(
  transaction: Transaction,
  adminId?: string
): Promise<{
  success: boolean;
  transaction?: Transaction;
  wallet?: Wallet;
  treasury?: CompanyTreasury;
  error?: string;
}> {
  try {
    const res = await apiFetch(`${API_BASE}/transactions/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transaction, adminId }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiUpdateTransaction] API failed, using direct Firestore:', err);
  }

  // Direct Firestore fallback for Vercel
  try {
    const fs = await fetchFullFirestoreState();
    const currentTxns = fs?.transactions || [];
    const currentWallets = fs?.wallets || {};
    const currentTreasury: CompanyTreasury = fs?.treasury || {
      balance: 1000000,
      minAlertThreshold: 500000,
      totalInjected: 1000000,
      totalDeducted: 0,
      totalTransferredToUsers: 0,
      lastUpdated: new Date().toISOString(),
    };

    const targetUserId = transaction.userId || '';
    const userWallet: Wallet = targetUserId ? getWalletForUser(targetUserId, currentWallets, fs?.users || []) : {
      cashBalance: 0,
      gpBalance: 0,
      totalInvested: 0,
      totalEarned: 0,
      royaltyEarned: 0,
      pendingWithdrawals: 0,
      pendingDeposits: 0,
      totalWithdrawn: 0,
    };

    const isApproved = (transaction.status as string) === 'SUCCESS' || (transaction.status as string) === 'APPROVED';
    const isRejected = (transaction.status as string) === 'REJECTED' || (transaction.status as string) === 'FAILED';

    if (transaction.type === 'DEPOSIT' && isApproved) {
      userWallet.cashBalance += transaction.amount;
      userWallet.pendingDeposits = Math.max(0, (userWallet.pendingDeposits || 0) - transaction.amount);
    } else if (transaction.type === 'DEPOSIT' && isRejected) {
      userWallet.pendingDeposits = Math.max(0, (userWallet.pendingDeposits || 0) - transaction.amount);
    } else if (transaction.type === 'WITHDRAWAL' && isApproved) {
      userWallet.pendingWithdrawals = Math.max(0, (userWallet.pendingWithdrawals || 0) - transaction.amount);
      userWallet.totalWithdrawn = (userWallet.totalWithdrawn || 0) + transaction.amount;
      currentTreasury.balance = Math.max(0, currentTreasury.balance - transaction.amount);
      currentTreasury.totalTransferredToUsers = (currentTreasury.totalTransferredToUsers || 0) + transaction.amount;
    } else if (transaction.type === 'WITHDRAWAL' && isRejected) {
      userWallet.pendingWithdrawals = Math.max(0, (userWallet.pendingWithdrawals || 0) - transaction.amount);
      if (transaction.withdrawalSource === 'ROYALTY') {
        userWallet.royaltyEarned += transaction.amount;
      } else {
        userWallet.totalEarned += transaction.amount;
      }
    }

    const updatedTxns = currentTxns.map((t) => (t.id === transaction.id ? { ...t, ...transaction } : t));
    if (targetUserId) {
      const updatedWallets = updateWalletForUserInMap(targetUserId, currentWallets, fs?.users || [], userWallet);
      await saveWalletsToFirestore(updatedWallets);
    }
    await saveTransactionsToFirestore(updatedTxns);
    await saveTreasuryToFirestore(currentTreasury);

    return { success: true, transaction, wallet: userWallet, treasury: currentTreasury };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message || 'Firestore write failed' };
  }
}

/**
 * Admin adds a manual transaction
 */
export async function apiAddTransaction(
  transaction: Transaction
): Promise<{ success: boolean; transaction?: Transaction; treasury?: CompanyTreasury; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/transactions/add`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transaction }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (result.treasury) {
          updateFirestoreBridgeCache({ treasury: result.treasury });
        }
        return result;
      }
    }
  } catch (err: any) {
    console.warn('[apiAddTransaction] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentTxns = fs?.transactions || [];
    const updated = [transaction, ...currentTxns.filter((t) => t.id !== transaction.id)];
    await saveTransactionsToFirestore(updated);
    
    let updatedTreasury = fs?.treasury;
    const amount = Number(transaction.amount || 0);
    if (transaction.status === 'SUCCESS' && (transaction.type === 'DEPOSIT' || transaction.type === 'ADMIN_ADD') && amount > 0 && fs?.treasury) {
      const prevBal = fs.treasury.balance || 0;
      const newBal = Math.max(0, prevBal - amount);
      updatedTreasury = {
        ...fs.treasury,
        balance: newBal,
        totalTransferredToUsers: (fs.treasury.totalTransferredToUsers || 0) + amount,
        totalDeducted: (fs.treasury.totalDeducted || 0) + amount,
      };
      await saveTreasuryToFirestore(updatedTreasury);
    }

    return { success: true, transaction, treasury: updatedTreasury };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin deletes a transaction
 */
export async function apiDeleteTransaction(
  transactionId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/transactions/${transactionId}`, {
      method: 'DELETE',
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiDeleteTransaction] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentTxns = fs?.transactions || [];
    const updated = currentTxns.filter((t) => t.id !== transactionId);
    await saveTransactionsToFirestore(updated);
    return { success: true };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * User subscribes / creates a new ActiveInvestment
 */
export async function apiCreateInvestment(
  investment: ActiveInvestment,
  userId: string,
  wallet?: Wallet
): Promise<{ success: boolean; investment?: ActiveInvestment; wallet?: Wallet; error?: string }> {
  if (wallet) {
    updateFirestoreBridgeCache({
      wallets: {
        [userId]: wallet,
      },
    });
  }

  try {
    const res = await apiFetch(`${API_BASE}/investments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ investment, userId, wallet }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (result.wallet) {
          updateFirestoreBridgeCache({
            wallets: {
              [userId]: result.wallet,
            },
          });
        }
        return result;
      }
    }
  } catch (err: any) {
    console.warn('[apiCreateInvestment] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentInvestments = fs?.investments || [];
    const currentWallets = fs?.wallets || {};
    const existingWallet = getWalletForUser(userId, currentWallets, fs?.users || []);
    let userWallet: Wallet = wallet ? { ...existingWallet, ...wallet } : { ...existingWallet };

    if (!wallet) {
      userWallet.gpBalance = Math.max(0, (userWallet.gpBalance || 0) - investment.investedAmount);
      userWallet.totalInvested = (userWallet.totalInvested || 0) + investment.investedAmount;
    }

    const updatedWallets = updateWalletForUserInMap(userId, currentWallets, fs?.users || [], userWallet);
    const updatedInvestments = [investment, ...currentInvestments.filter((i) => i.id !== investment.id)];

    await saveInvestmentsToFirestore(updatedInvestments);
    await saveWalletsToFirestore(updatedWallets);

    updateFirestoreBridgeCache({
      wallets: {
        [userId]: userWallet,
      },
    });

    return { success: true, investment, wallet: userWallet };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Updates an existing investment (earnings collection, cycle advance, renewal, completion)
 */
export async function apiUpdateInvestment(
  investment: ActiveInvestment,
  walletUpdatesOrUserId?: Partial<Wallet> | string,
  userId?: string
): Promise<{ success: boolean; investment?: ActiveInvestment; wallet?: Wallet; error?: string }> {
  let resolvedWalletUpdates: Partial<Wallet> | undefined;
  let resolvedUserId: string | undefined = userId;

  if (typeof walletUpdatesOrUserId === 'string') {
    resolvedUserId = walletUpdatesOrUserId;
  } else if (walletUpdatesOrUserId && typeof walletUpdatesOrUserId === 'object') {
    resolvedWalletUpdates = walletUpdatesOrUserId;
  }

  try {
    const res = await apiFetch(`${API_BASE}/investments/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ investment, walletUpdates: resolvedWalletUpdates, userId: resolvedUserId }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiUpdateInvestment] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentInvestments = fs?.investments || [];
    const updatedInvestments = currentInvestments.map((i) => (i.id === investment.id ? { ...i, ...investment } : i));
    await saveInvestmentsToFirestore(updatedInvestments);

    let updatedWallet: Wallet | undefined;
    if (resolvedUserId && resolvedWalletUpdates && fs?.wallets) {
      const currentWallets = fs.wallets;
      const cur = getWalletForUser(resolvedUserId, currentWallets, fs?.users || []);
      updatedWallet = { ...cur, ...resolvedWalletUpdates };
      const updatedWallets = updateWalletForUserInMap(resolvedUserId, currentWallets, fs?.users || [], updatedWallet);
      await saveWalletsToFirestore(updatedWallets);
    }

    return { success: true, investment, wallet: updatedWallet };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin saves updated investment plans to central database
 */
export async function apiSavePlans(
  plans: InvestmentPlan[]
): Promise<{ success: boolean; plans?: InvestmentPlan[]; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/plans/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plans }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSavePlans] API failed, using direct Firestore:', err);
  }

  try {
    await savePlansToFirestore(plans);
    return { success: true, plans };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin saves updated platform rules to central database
 */
export async function apiSaveRules(
  rules: AppRules
): Promise<{ success: boolean; rules?: AppRules; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/rules/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rules }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSaveRules] API failed, using direct Firestore:', err);
  }

  try {
    await saveRulesToFirestore(rules);
    return { success: true, rules };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin saves live interface config (announcements, QR, UPI, etc.)
 */
export async function apiSaveLiveConfig(
  liveConfig: LiveInterfaceConfig
): Promise<{ success: boolean; liveConfig?: LiveInterfaceConfig; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/live-config/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ liveConfig }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSaveLiveConfig] API failed, using direct Firestore:', err);
  }

  try {
    await saveLiveConfigToFirestore(liveConfig);
    return { success: true, liveConfig };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin updates company treasury balance and logs
 */
export async function apiUpdateTreasury(
  treasury: CompanyTreasury,
  log?: TreasuryLog | TreasuryLog[]
): Promise<{ success: boolean; treasury?: CompanyTreasury; logs?: TreasuryLog[]; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/treasury/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ treasury, log }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiUpdateTreasury] API failed, using direct Firestore:', err);
  }

  try {
    const logsArray = log ? (Array.isArray(log) ? log : [log]) : undefined;
    await saveTreasuryToFirestore(treasury, logsArray);
    return { success: true, treasury, logs: logsArray };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * User saves bank / UPI details
 */
export async function apiSaveBankDetails(
  userId: string,
  details: BankAccountDetails
): Promise<{ success: boolean; details?: BankAccountDetails; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/bank-details`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, details }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSaveBankDetails] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentBank = fs?.bankDetails || {};
    currentBank[userId] = details;
    await saveBankDetailsToFirestore(currentBank);
    return { success: true, details };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Admin adjusts a user's wallet (Add amount, Deduct amount, or Direct balance set)
 */
export async function apiAdminAdjustUserWallet(
  userId: string,
  wallet: Partial<Wallet>,
  adjustment?: {
    type: 'ADD' | 'DEDUCT' | 'SET';
    targetWallet: 'cashBalance' | 'gpBalance' | 'totalEarned' | 'royaltyEarned' | 'pendingDeposits' | 'pendingWithdrawals';
    amount: number;
    reason?: string;
  },
  adminName?: string
): Promise<{ success: boolean; wallet?: Wallet; treasury?: CompanyTreasury; error?: string }> {
  if (!userId) {
    return { success: false, error: 'User ID is required' };
  }

  try {
    const res = await apiFetch(`${API_BASE}/admin/user-wallet/adjust`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, wallet, adjustment, adminName }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (result.wallet) {
          const cachedFs = getCachedFirestoreState();
          const { aliases } = findUserAndAllAliases(userId, cachedFs?.users || []);
          const aliasWallets: Record<string, Wallet> = {};
          aliases.forEach((a) => {
            if (a) aliasWallets[a] = result.wallet!;
          });
          updateFirestoreBridgeCache({
            wallets: aliasWallets,
            ...(result.treasury ? { treasury: result.treasury } : {})
          });

          // Non-blocking background Firestore sync
          fetchFullFirestoreState().then((fs) => {
            const currentWallets = fs?.wallets || {};
            const updatedWallets = updateWalletForUserInMap(userId, currentWallets, fs?.users || [], result.wallet);
            saveWalletsToFirestore(updatedWallets).catch(() => {});
            if (result.treasury) {
              saveTreasuryToFirestore(result.treasury, result.treasuryLogs).catch(() => {});
            }
          }).catch((fsSyncErr) => {
            console.warn('[apiAdminAdjustUserWallet] Direct Firestore sync warn:', fsSyncErr);
          });
        }
        return result;
      }
    }
  } catch (err: any) {
    console.warn('[apiAdminAdjustUserWallet] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentWallets = fs?.wallets || {};
    const existing = getWalletForUser(userId, currentWallets, fs?.users || []);

    const finalWallet: Wallet = { ...existing, ...wallet };
    let updatedTreasury = fs?.treasury;
    
    // Calculate net transfer to user and update treasury accordingly
    let netTransferToUser = 0;
    if (adjustment && typeof adjustment.amount === 'number' && adjustment.amount !== 0) {
      const amount = Number(adjustment.amount);
      const adjType = adjustment.type || 'ADD';
      const targetWallet = adjustment.targetWallet || 'cashBalance';
      const currentVal = existing[targetWallet] || 0;
      
      let calculatedVal = currentVal;
      if (adjType === 'ADD') {
        calculatedVal = currentVal + amount;
        netTransferToUser = amount;
      } else if (adjType === 'DEDUCT') {
        calculatedVal = Math.max(0, currentVal - amount);
        netTransferToUser = -amount;
      } else if (adjType === 'SET') {
        calculatedVal = Math.max(0, amount);
        netTransferToUser = amount - currentVal;
      }
      finalWallet[targetWallet] = calculatedVal;
    } else if (wallet && typeof wallet === 'object') {
      const cashDiff = typeof wallet.cashBalance === 'number' ? (wallet.cashBalance - (existing.cashBalance || 0)) : 0;
      const gpDiff = typeof wallet.gpBalance === 'number' ? (wallet.gpBalance - (existing.gpBalance || 0)) : 0;
      const earnDiff = typeof wallet.totalEarned === 'number' ? (wallet.totalEarned - (existing.totalEarned || 0)) : 0;
      const royDiff = typeof wallet.royaltyEarned === 'number' ? (wallet.royaltyEarned - (existing.royaltyEarned || 0)) : 0;
      netTransferToUser = cashDiff + gpDiff + earnDiff + royDiff;
    }

    if (fs?.treasury && netTransferToUser !== 0) {
      const prevBal = fs.treasury.balance || 0;
      if (netTransferToUser > 0) {
        // Funds given to user -> Treasury decreases
        updatedTreasury = {
          ...fs.treasury,
          balance: Math.max(0, prevBal - netTransferToUser),
          totalTransferredToUsers: (fs.treasury.totalTransferredToUsers || 0) + netTransferToUser,
          totalDeducted: (fs.treasury.totalDeducted || 0) + netTransferToUser,
        };
      } else {
        // Funds deducted/reclaimed from user -> Treasury increases
        const reclaimAmt = Math.abs(netTransferToUser);
        updatedTreasury = {
          ...fs.treasury,
          balance: prevBal + reclaimAmt,
          totalAdded: (fs.treasury.totalAdded || 0) + reclaimAmt,
        };
      }
      await saveTreasuryToFirestore(updatedTreasury);
    }

    const updatedWallets = updateWalletForUserInMap(userId, currentWallets, fs?.users || [], finalWallet);
    await saveWalletsToFirestore(updatedWallets);

    return { success: true, wallet: finalWallet, treasury: updatedTreasury };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Updates wallet on server (supports either (userId, wallet) or (wallet, userId))
 */
export async function apiUpdateWallet(
  arg1: string | Wallet,
  arg2?: string | Wallet
): Promise<{ success: boolean; wallet?: Wallet; error?: string }> {
  const userId = typeof arg1 === 'string' ? arg1 : (typeof arg2 === 'string' ? arg2 : '');
  const wallet = (typeof arg1 === 'object' ? arg1 : (typeof arg2 === 'object' ? arg2 : undefined)) as Wallet | undefined;

  if (!userId || !wallet) {
    return { success: false, error: 'Invalid wallet or userId' };
  }

  try {
    const res = await apiFetch(`${API_BASE}/wallet/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, wallet }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (result.wallet) {
          const { aliases } = findUserAndAllAliases(userId, []);
          const walletsMap: Record<string, Wallet> = {};
          aliases.forEach(alias => {
            if (alias) walletsMap[alias] = result.wallet;
          });
          updateFirestoreBridgeCache({
            wallets: walletsMap
          });
        }
        return result;
      }
    }
  } catch (err: any) {
    console.warn('[apiUpdateWallet] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentWallets = fs?.wallets || {};
    const updatedWallets = updateWalletForUserInMap(userId, currentWallets, fs?.users || [], wallet);
    await saveWalletsToFirestore(updatedWallets);

    const { aliases } = findUserAndAllAliases(userId, fs?.users || []);
    const walletsMap: Record<string, Wallet> = {};
    aliases.forEach(alias => {
      if (alias) walletsMap[alias] = wallet;
    });
    updateFirestoreBridgeCache({
      wallets: walletsMap
    });

    return { success: true, wallet };
  } catch (fsErr: any) {
    return { success: false, error: fsErr.message };
  }
}

/**
 * Fetch messages from central database
 */
export async function apiFetchMessages(
  userId?: string,
  role: UserRole = 'USER'
): Promise<{ success: boolean; messages: AdminMessage[] }> {
  try {
    const params = new URLSearchParams();
    if (userId) params.append('userId', userId);
    params.append('role', role);
    params.append('t', Date.now().toString());

    const res = await apiFetch(`${API_BASE}/messages?${params.toString()}`);
    if (res.ok) {
      const data = await res.json().catch(() => null);
      if (data && data.messages) return { success: true, messages: data.messages };
    }
  } catch (err) {
    console.warn('[apiFetchMessages] API failed, using direct Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState();
    const allMsgs = fs?.messages || [];
    const isReqAdmin = role === 'ADMIN' || String(role).toUpperCase() === 'ADMIN';
    if (isReqAdmin) {
      return { success: true, messages: allMsgs };
    } else {
      const { aliases } = userId ? findUserAndAllAliases(userId, fs?.users || []) : { aliases: [] };
      const lowerAliases = aliases.map((a) => a.toLowerCase());
      const filtered = allMsgs.filter((m) => {
        if (!m) return false;
        if (m.targetType === 'ALL' || !m.targetType || m.targetUserId === 'ALL') return true;
        if (m.targetType === 'SINGLE') {
          const tId = (m.targetUserId || '').toLowerCase();
          const tLogin = (m.targetUserLoginId || '').toLowerCase();
          return lowerAliases.includes(tId) || lowerAliases.includes(tLogin);
        }
        if (m.targetType === 'SELECTED') {
          if (!Array.isArray(m.targetUserIds)) return false;
          const selectedList = m.targetUserIds.map((id: any) => String(id).toLowerCase());
          return lowerAliases.some((alias) => selectedList.includes(alias));
        }
        if (userId && (m.targetUserId === userId || (Array.isArray(m.targetUserIds) && m.targetUserIds.includes(userId)))) return true;
        return false;
      });
      return { success: true, messages: filtered };
    }
  } catch {
    return { success: false, messages: [] };
  }
}

/**
 * Admin broadcasts a message
 */
export async function apiSendAdminMessage(
  message: Partial<AdminMessage>
): Promise<{ success: boolean; message?: AdminMessage; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/admin/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSendAdminMessage] API failed, creating fallback message:', err);
  }

  try {
    const newMsg: AdminMessage = {
      id: message.id || `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: message.title || '',
      titleHi: message.titleHi || message.title || '',
      content: message.content || '',
      contentHi: message.contentHi || message.content || '',
      type: message.type || 'INFO',
      senderName: message.senderName || 'GCap Official Admin',
      targetType: message.targetType || 'ALL',
      targetUserId: message.targetUserId,
      targetUserLoginId: message.targetUserLoginId,
      targetUserName: message.targetUserName,
      targetUserIds: message.targetUserIds,
      priority: message.priority || 'NORMAL',
      category: message.category || 'ANNOUNCEMENT',
      showPopup: message.showPopup !== false,
      showAsPopup: message.showPopup !== false,
      createdAt: message.createdAt || new Date().toISOString(),
      timestamp: message.timestamp || Date.now(),
      expiresAt: message.expiresAt,
      readByUserIds: message.readByUserIds || [],
      dismissedByUserIds: message.dismissedByUserIds || [],
      actionLabel: message.actionLabel,
      actionUrl: message.actionUrl,
    };

    try {
      const fs = await fetchFullFirestoreState().catch(() => null);
      const currentMsgs = fs?.messages || [];
      const updated = [newMsg, ...currentMsgs.filter((m: any) => m.id !== newMsg.id)];
      saveMessagesToFirestore(updated).catch(() => {});
    } catch (_) {}

    return { success: true, message: newMsg };
  } catch (fsErr: any) {
    return { success: false, error: fsErr?.message || 'Failed to send message' };
  }
}

/**
 * Sync historical messages batch to the server
 */
export async function apiSyncAdminMessagesBatch(
  messagesList: AdminMessage[]
): Promise<{ success: boolean; syncedCount?: number; totalMessages?: number; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/admin/messages/sync-batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: messagesList }),
    });
    if (res.ok) {
      const result = await res.json().catch(() => null);
      if (result && result.success) return result;
    }
  } catch (err: any) {
    console.warn('[apiSyncAdminMessagesBatch] API failed, syncing directly to Firestore:', err);
  }

  try {
    const fs = await fetchFullFirestoreState().catch(() => null);
    const currentMsgs = fs?.messages || [];
    
    // Dedupe and merge with local list
    const map = new Map<string, AdminMessage>();
    for (const m of currentMsgs) {
      if (m && m.id) map.set(m.id, m);
    }
    let added = 0;
    for (const m of messagesList) {
      if (m && m.id && !map.has(m.id)) {
        map.set(m.id, m);
        added++;
      }
    }
    const merged = Array.from(map.values()).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    await saveMessagesToFirestore(merged).catch(() => {});
    return { success: true, syncedCount: added, totalMessages: merged.length };
  } catch (fsErr: any) {
    return { success: false, error: fsErr?.message || 'Failed to sync messages' };
  }
}

/**
 * Mark a message as read by user
 */
export async function apiMarkMessageRead(
  messageId: string,
  userId: string
): Promise<{ success: boolean }> {
  try {
    const res = await apiFetch(`${API_BASE}/messages/${messageId}/read`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    if (res.ok) return await res.json();
  } catch {
    // ignore
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentMsgs = fs?.messages || [];
    const updated = currentMsgs.map((m) => {
      if (m.id === messageId && !m.readByUserIds.includes(userId)) {
        return { ...m, readByUserIds: [...m.readByUserIds, userId] };
      }
      return m;
    });
    await saveMessagesToFirestore(updated);
    return { success: true };
  } catch {
    return { success: false };
  }
}

/**
 * Dismiss a message popup for a user
 */
export async function apiDismissMessagePopup(
  messageId: string,
  userId: string
): Promise<{ success: boolean }> {
  try {
    const res = await apiFetch(`${API_BASE}/messages/${messageId}/dismiss`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId }),
    });
    if (res.ok) return await res.json();
  } catch {
    // ignore
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentMsgs = fs?.messages || [];
    const updated = currentMsgs.map((m) => {
      if (m.id === messageId && !m.dismissedByUserIds.includes(userId)) {
        return { ...m, dismissedByUserIds: [...m.dismissedByUserIds, userId] };
      }
      return m;
    });
    await saveMessagesToFirestore(updated);
    return { success: true };
  } catch {
    return { success: false };
  }
}

export const apiDismissMessage = apiDismissMessagePopup;

/**
 * Admin deletes a message
 */
export async function apiDeleteAdminMessage(
  messageId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await apiFetch(`${API_BASE}/admin/messages/${messageId}`, {
      method: 'DELETE',
    });
    if (res.ok) return await res.json();
  } catch {
    // ignore
  }

  try {
    const fs = await fetchFullFirestoreState();
    const currentMsgs = fs?.messages || [];
    const updated = currentMsgs.filter((m) => m.id !== messageId);
    await saveMessagesToFirestore(updated);
    return { success: true };
  } catch {
    return { success: false };
  }
}

/**
 * Global API Event Listeners to break circular dependencies with storage modules
 */
if (typeof window !== 'undefined') {
  window.addEventListener('gcap_api_save_plans', (e: any) => {
    if (e.detail) {
      apiSavePlans(e.detail).catch(err => console.warn('[CentralSync] Global save plans error:', err));
    }
  });

  window.addEventListener('gcap_api_save_rules', (e: any) => {
    if (e.detail) {
      apiSaveRules(e.detail).catch(err => console.warn('[CentralSync] Global save rules error:', err));
    }
  });

  window.addEventListener('gcap_api_save_live_config', (e: any) => {
    if (e.detail) {
      apiSaveLiveConfig(e.detail).catch(err => console.warn('[CentralSync] Global save live config error:', err));
    }
  });
}
