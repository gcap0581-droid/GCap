import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  User,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  Users,
  CheckCircle2,
  Sparkles,
  Smartphone,
  Monitor,
  Globe,
  AlertCircle,
  HelpCircle,
  Check,
  CreditCard,
  FileCheck,
  Send,
  RefreshCw,
  KeyRound,
  Shield,
  BadgeCheck,
} from 'lucide-react';
import { Language, UserProfile, ViewMode } from '../types';
import { loginUserAsync, registerUserAsync, syncUsersWithServer, AUTH_USER_KEY, getAllUsers } from '../utils/authStorage';
import { audioAnnouncer } from '../utils/audioAnnouncer';
import { PRIMARY_COMPANY_LOGO } from '../utils/logoAssets';
import {
  sendFirebasePhoneOtp,
  verifyFirebasePhoneOtp,
  verifyPanCardApi,
  sendAadhaarOtpApi,
  verifyAadhaarOtpApi,
  formatAadhaarNumber,
  validatePanStructure,
} from '../utils/kycVerification';

interface LoginPageProps {
  onLoginSuccess: (user: UserProfile) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  language,
  onLanguageChange,
  viewMode,
  onViewModeChange,
}) => {
  const isHi = language === 'hi';
  const [authMode, setAuthMode] = useState<'LOGIN' | 'REGISTER'>('LOGIN');

  // Login form state (strictly blank by default)
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isIdActive, setIsIdActive] = useState(false);
  const [isPassActive, setIsPassActive] = useState(false);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regLoginId, setRegLoginId] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regReferral, setRegReferral] = useState('');
  const [isReferralLocked, setIsReferralLocked] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Real KYC Verification State
  // 1. Mobile OTP (Firebase Phone Auth)
  const [isPhoneOtpSent, setIsPhoneOtpSent] = useState(false);
  const [phoneOtp, setPhoneOtp] = useState('');
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const [phoneOtpSending, setPhoneOtpSending] = useState(false);
  const [phoneOtpVerifying, setPhoneOtpVerifying] = useState(false);
  const [phoneTestOtpHint, setPhoneTestOtpHint] = useState<string | null>(null);
  const [phoneResendTimer, setPhoneResendTimer] = useState(0);

  // 2. PAN Verification
  const [panNumber, setPanNumber] = useState('');
  const [isPanVerifying, setIsPanVerifying] = useState(false);
  const [isPanVerified, setIsPanVerified] = useState(false);
  const [panHolderName, setPanHolderName] = useState('');

  // 3. Aadhaar Verification
  const [aadhaarNumber, setAadhaarNumber] = useState('');
  const [isAadhaarOtpSent, setIsAadhaarOtpSent] = useState(false);
  const [aadhaarClientId, setAadhaarClientId] = useState('');
  const [aadhaarOtp, setAadhaarOtp] = useState('');
  const [isAadhaarOtpSending, setIsAadhaarOtpSending] = useState(false);
  const [isAadhaarVerifying, setIsAadhaarVerifying] = useState(false);
  const [isAadhaarVerified, setIsAadhaarVerified] = useState(false);
  const [maskedAadhaar, setMaskedAadhaar] = useState('');
  const [aadhaarTestOtpHint, setAadhaarTestOtpHint] = useState<string | null>(null);

  // KYC Section Accordion Toggle
  const [showKycSection, setShowKycSection] = useState(false);

  // Sync users on mount
  React.useEffect(() => {
    syncUsersWithServer();
  }, []);

  // Countdown timer for Phone OTP Resend
  React.useEffect(() => {
    if (phoneResendTimer <= 0) return;
    const timer = setInterval(() => {
      setPhoneResendTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [phoneResendTimer]);

  // Auto-detect referral code in URL parameter or local storage when opened via share link
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const searchParams = new URLSearchParams(window.location.search);
        let refParam = searchParams.get('ref') || searchParams.get('referral') || searchParams.get('sponsor') || searchParams.get('code');
        
        // Also check hash parameters if URL routing was in hash (e.g. #/?ref=...)
        if (!refParam && window.location.hash.includes('?')) {
          const hashQuery = window.location.hash.split('?')[1];
          const hashParams = new URLSearchParams(hashQuery);
          refParam = hashParams.get('ref') || hashParams.get('referral') || hashParams.get('sponsor') || hashParams.get('code');
        }

        // Also check full href regex fallback for robustness
        if (!refParam) {
          const match = window.location.href.match(/[?&](?:ref|referral|sponsor|code)=([^&#]+)/i);
          if (match && match[1]) {
            refParam = decodeURIComponent(match[1]);
          }
        }

        const savedRef = localStorage.getItem('gcap_saved_referral_code') || sessionStorage.getItem('gcap_saved_referral_code');
        
        const codeToLock = refParam || savedRef;
        if (codeToLock) {
          const cleanCode = codeToLock.trim().toUpperCase();
          setRegReferral(cleanCode);
          setIsReferralLocked(true);
          localStorage.setItem('gcap_saved_referral_code', cleanCode);
          sessionStorage.setItem('gcap_saved_referral_code', cleanCode);
          if (refParam) {
            setAuthMode('REGISTER');
          }
        } else {
          // Direct registration: Default to GCAP-DIRECT (editable)
          setRegReferral('GCAP-DIRECT');
          setIsReferralLocked(false);
        }
      } catch (err) {
        console.warn('Error reading referral param:', err);
      }
    }
  }, []);

  // Error & Loading states
  const [errorMessage, setErrorMessage] = useState('');
  const [isIdValid, setIsIdValid] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Strict check: registration button is ONLY enabled when all fields, OTP, PAN & Aadhaar are fully verified
  const cleanRegPhone = regPhone.replace(/[^0-9]/g, '');
  const isRegistrationValid = Boolean(
    regName.trim().length >= 2 &&
    cleanRegPhone.length === 10 &&
    isPhoneVerified &&
    regPassword.trim().length >= 4 &&
    isPanVerified &&
    isAadhaarVerified &&
    agreeTerms
  );

  const handleLoginIdChange = async (newId: string) => {
    setLoginId(newId);
    setErrorMessage('');
    const trimmedId = newId.trim();
    if (!trimmedId) {
      setIsIdValid(false);
      return;
    }
    const allUsers = await getAllUsersAsync();
    const isValid = allUsers.some(u => 
      u.loginId === trimmedId || 
      (u.phone && u.phone.replace(/[^0-9]/g, '').slice(-10) === trimmedId.replace(/[^0-9]/g, '').slice(-10))
    ) || trimmedId.toLowerCase() === 'admin';
    setIsIdValid(isValid);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const trimmedLogin = loginId.trim();
    const trimmedPass = password.trim();

    if (!trimmedLogin) {
      setErrorMessage(isHi ? 'कृपया मोबाइल नंबर या यूजर आईडी दर्ज करें।' : 'Please enter Mobile Number or User ID.');
      return;
    }

    if (!trimmedPass) {
      setErrorMessage(isHi ? 'कृपया पासवर्ड दर्ज करें।' : 'Please enter password.');
      return;
    }

    const cleanDigits = trimmedLogin.replace(/[^0-9]/g, '');
    const clean10 = cleanDigits.length >= 10 ? cleanDigits.slice(-10) : cleanDigits;
    const isMasterAdmin = trimmedLogin.toLowerCase() === 'admin';
    const isMasterPass = trimmedPass === 'ad123';

    // Direct Instant Admin Login Guarantee
    if (isMasterAdmin && isMasterPass) {
      const adminUser = {
        id: 'usr-admin-01',
        loginId: 'admin',
        name: 'GCap System Administrator',
        role: 'ADMIN' as const,
        phone: '+91 98000 12345',
        email: 'support@gcapopc.com',
        joinedDate: '2026-01-01',
        status: 'ACTIVE' as const,
        isOnline: true,
        lastLoginAt: new Date().toISOString(),
        lastActiveAt: new Date().toISOString(),
        permissions: {
          manageUsers: true,
          manageWallet: true,
          manageTransactions: true,
          manageSchemes: true,
          manageTreasury: true,
          manageBroadcast: true,
        },
      };

      try {
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(adminUser));
        sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(adminUser));
      } catch (_) {}

      // Inform parent and enter dashboard
      onLoginSuccess(adminUser);
      return;
    }

    // Standard user login
    setIsLoading(true);

    try {
      const res = await loginUserAsync(loginId, password);
      setIsLoading(false);
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setErrorMessage(res.error || (isHi ? 'लॉगिन विफल रहा' : 'Login failed'));
      }
    } catch {
      setIsLoading(false);
      setErrorMessage(isHi ? 'लॉगिन त्रुटि हुई। कृपया पुनः प्रयास करें।' : 'Login error. Please try again.');
    }
  };

  const handleSendPhoneOtp = async () => {
    const cleanDigits = regPhone.replace(/[^0-9]/g, '');
    if (!cleanDigits || cleanDigits.length < 10) {
      setErrorMessage(isHi ? 'कृपया पहले 10 अंकों का मान्य मोबाइल नंबर दर्ज करें।' : 'Please enter valid 10-digit mobile number first.');
      return;
    }
    setErrorMessage('');
    setPhoneOtpSending(true);
    try {
      const res = await sendFirebasePhoneOtp(cleanDigits, 'recaptcha-phone-container');
      setPhoneOtpSending(false);
      if (res.success) {
        setIsPhoneOtpSent(true);
        setPhoneResendTimer(30);
        if (res.testOtp) setPhoneTestOtpHint(res.testOtp);
      } else {
        setErrorMessage(res.error || (isHi ? 'OTP भेजने में त्रुटि हुई।' : 'Error sending phone OTP.'));
      }
    } catch {
      setPhoneOtpSending(false);
      setErrorMessage(isHi ? 'OTP भेजने में विफल।' : 'Failed to send phone OTP.');
    }
  };

  const handleVerifyPhoneOtp = async () => {
    if (!phoneOtp || phoneOtp.trim().length < 4) {
      setErrorMessage(isHi ? 'कृपया 6-अंकीय मान्य OTP दर्ज करें।' : 'Please enter 6-digit OTP code.');
      return;
    }
    setErrorMessage('');
    setPhoneOtpVerifying(true);
    try {
      const res = await verifyFirebasePhoneOtp(phoneOtp, phoneTestOtpHint || undefined);
      setPhoneOtpVerifying(false);
      if (res.success) {
        setIsPhoneVerified(true);
        setIsPhoneOtpSent(false);
      } else {
        setErrorMessage(res.error || (isHi ? 'गलत OTP कोड दर्ज किया गया है।' : 'Invalid OTP entered.'));
      }
    } catch {
      setPhoneOtpVerifying(false);
      setErrorMessage(isHi ? 'OTP सत्यापन विफल रहा।' : 'OTP verification failed.');
    }
  };

  const handleVerifyPan = async () => {
    const cleanPan = panNumber.trim().toUpperCase();
    if (!validatePanStructure(cleanPan)) {
      setErrorMessage(isHi ? 'कृपया 10-अक्षरों का मान्य पैन नंबर दर्ज करें (उदा. ABCDE1234F)' : 'Please enter valid 10-digit PAN (e.g. ABCDE1234F)');
      return;
    }
    setErrorMessage('');
    setIsPanVerifying(true);
    try {
      const res = await verifyPanCardApi(cleanPan, regName);
      setIsPanVerifying(false);
      if (res.success) {
        setIsPanVerified(true);
        setPanHolderName(res.holderName || regName);
      } else {
        setErrorMessage(res.error || (isHi ? 'पैन सत्यापन विफल रहा।' : 'PAN verification failed.'));
      }
    } catch {
      setIsPanVerifying(false);
      setErrorMessage(isHi ? 'पैन सत्यापन में त्रुटि हुई।' : 'Error verifying PAN.');
    }
  };

  const handleSendAadhaarOtp = async () => {
    const cleanAadhaar = aadhaarNumber.replace(/[^0-9]/g, '');
    if (cleanAadhaar.length !== 12) {
      setErrorMessage(isHi ? 'कृपया 12-अंकीय आधार कार्ड नंबर दर्ज करें।' : 'Please enter 12-digit Aadhaar number.');
      return;
    }
    setErrorMessage('');
    setIsAadhaarOtpSending(true);
    try {
      const res = await sendAadhaarOtpApi(cleanAadhaar);
      setIsAadhaarOtpSending(false);
      if (res.success && res.clientId) {
        setIsAadhaarOtpSent(true);
        setAadhaarClientId(res.clientId);
        if (res.testOtp) setAadhaarTestOtpHint(res.testOtp);
      } else {
        setErrorMessage(res.error || (isHi ? 'आधार OTP भेजने में त्रुटि हुई।' : 'Error sending Aadhaar OTP.'));
      }
    } catch {
      setIsAadhaarOtpSending(false);
      setErrorMessage(isHi ? 'आधार OTP भेजने में असमर्थ।' : 'Unable to send Aadhaar OTP.');
    }
  };

  const handleVerifyAadhaarOtp = async () => {
    if (!aadhaarOtp || aadhaarOtp.trim().length < 4) {
      setErrorMessage(isHi ? 'कृपया 6-अंकीय आधार OTP दर्ज करें।' : 'Please enter 6-digit Aadhaar OTP.');
      return;
    }
    setErrorMessage('');
    setIsAadhaarVerifying(true);
    try {
      const res = await verifyAadhaarOtpApi(aadhaarClientId, aadhaarOtp, aadhaarNumber);
      setIsAadhaarVerifying(false);
      if (res.success) {
        setIsAadhaarVerified(true);
        setIsAadhaarOtpSent(false);
        setMaskedAadhaar(res.maskedAadhaar || `XXXX XXXX ${aadhaarNumber.replace(/[^0-9]/g, '').slice(-4)}`);
      } else {
        setErrorMessage(res.error || (isHi ? 'आधार OTP सत्यापन विफल रहा।' : 'Aadhaar OTP verification failed.'));
      }
    } catch {
      setIsAadhaarVerifying(false);
      setErrorMessage(isHi ? 'आधार सत्यापन में त्रुटि हुई।' : 'Aadhaar verification error.');
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!regName.trim() || regName.trim().length < 2) {
      setErrorMessage(isHi ? 'कृपया अपना पूरा नाम दर्ज करें।' : 'Please enter your full name.');
      return;
    }

    const cleanDigits = regPhone.replace(/[^0-9]/g, '');
    if (!cleanDigits || cleanDigits.length < 10) {
      setErrorMessage(isHi ? 'कृपया 10 अंकों का मान्य मोबाइल नंबर दर्ज करें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }

    if (!isPhoneVerified) {
      setErrorMessage(isHi ? 'कृपया पहले मोबाइल नंबर पर SMS OTP भेजकर वेरिफाई करें।' : 'Please verify mobile number with SMS OTP first.');
      return;
    }

    if (!regPassword.trim() || regPassword.trim().length < 4) {
      setErrorMessage(isHi ? 'पासवर्ड कम से कम 4 अक्षरों का होना चाहिए।' : 'Password must be at least 4 characters long.');
      return;
    }

    if (!isPanVerified) {
      setErrorMessage(isHi ? 'कृपया पैन कार्ड नंबर दर्ज करके "पैन जांचें" से वेरिफाई करें।' : 'Please enter PAN card and verify via "Verify PAN".');
      return;
    }

    if (!isAadhaarVerified) {
      setErrorMessage(isHi ? 'कृपया आधार कार्ड नंबर दर्ज करके OTP द्वारा वेरिफाई करें।' : 'Please enter Aadhaar number and verify via OTP.');
      return;
    }

    if (!agreeTerms) {
      setErrorMessage(isHi ? 'कृपया नियम व शर्तों को स्वीकार करें' : 'Please accept terms & conditions');
      return;
    }

    setIsLoading(true);

    try {
      const res = await registerUserAsync({
        name: regName,
        loginId: cleanDigits.slice(-10),
        phone: cleanDigits.slice(-10),
        email: regEmail,
        password: regPassword,
        referralCode: regReferral,
        isPhoneVerified: isPhoneVerified,
        phoneVerifiedAt: isPhoneVerified ? new Date().toISOString() : undefined,
        panNumber: panNumber ? panNumber.toUpperCase().trim() : undefined,
        isPanVerified: isPanVerified,
        panVerifiedAt: isPanVerified ? new Date().toISOString() : undefined,
        panHolderName: panHolderName || (isPanVerified ? regName : undefined),
        aadhaarNumber: isAadhaarVerified ? maskedAadhaar : (aadhaarNumber ? formatAadhaarNumber(aadhaarNumber) : undefined),
        isAadhaarVerified: isAadhaarVerified,
        aadhaarVerifiedAt: isAadhaarVerified ? new Date().toISOString() : undefined,
        kycStatus: (isPanVerified && isAadhaarVerified) ? 'VERIFIED' : (isPhoneVerified ? 'PENDING' : 'NOT_SUBMITTED'),
      });

      setIsLoading(false);

      if (res.success && res.user) {
        // Sync with server in background without blocking login
        syncUsersWithServer().catch(() => {});
        audioAnnouncer.announceRegistration({
          userName: res.user.name,
          language: isHi ? 'hi' : 'en',
        });
        onLoginSuccess(res.user);
      } else {
        setErrorMessage(res.error || (isHi ? 'पंजीकरण विफल रहा' : 'Registration failed'));
      }
    } catch {
      setIsLoading(false);
      setErrorMessage(isHi ? 'पंजीकरण त्रुटि हुई। कृपया पुनः प्रयास करें।' : 'Registration error. Please try again.');
    }
  };

  return (
    <div className="w-full min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col justify-start selection:bg-emerald-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md px-4 sm:px-8 py-3.5 flex items-center justify-between sticky top-0 z-30 shadow-md shrink-0">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-400 to-amber-400 p-0.5 flex items-center justify-center shadow-xl shadow-emerald-500/30 animate-pulse-slow">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden border border-white/10">
              <img 
                src={PRIMARY_COMPANY_LOGO} 
                onError={(e) => {
                  const img = e.currentTarget as HTMLImageElement;
                  if (!img.dataset.triedFallback1) {
                    img.dataset.triedFallback1 = 'true';
                    img.src = '/assets/images/gcap-luxury-gold-3d.jpg';
                  } else if (!img.dataset.triedFallback2) {
                    img.dataset.triedFallback2 = 'true';
                    img.src = '/assets/images/logo.jpg';
                  } else if (!img.dataset.triedFallback3) {
                    img.dataset.triedFallback3 = 'true';
                    img.src = '/logo.jpg';
                  }
                }}
                alt="GCap Logo" 
                className="w-full h-full object-cover scale-110"
              />
            </div>
          </div>
          <div>
            <div className="flex items-center">
              <span className="font-extrabold text-xl sm:text-2xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-400 bg-clip-text text-transparent font-sans">
                GCap
              </span>
            </div>
            <p className="text-[10px] text-slate-400 tracking-wider uppercase">
              {isHi ? 'सुरक्षित वेल्थ व दैनिक रिटर्न पोर्टल' : 'Secure Wealth & Daily ROI Portal'}
            </p>
          </div>
        </div>

        {/* Header Right Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* View Mode Toggle */}
          <div className="hidden sm:flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => onViewModeChange('web')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                viewMode === 'web'
                  ? 'bg-slate-800 text-emerald-400 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Web</span>
            </button>
            <button
              onClick={() => onViewModeChange('android')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                (viewMode as string) === 'android'
                  ? 'bg-slate-800 text-emerald-400 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile</span>
            </button>
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => onLanguageChange(isHi ? 'en' : 'hi')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isHi ? 'English' : 'हिंदी'}</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full px-3.5 pt-2 sm:pt-6 pb-6 sm:p-6 lg:p-8 flex flex-col items-center justify-start sm:justify-center">
        <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-8 items-start lg:items-center">
          
          {/* Left Hero & Features Banner (Visible on Desktop/Tablet) */}
          <div className="lg:col-span-6 space-y-6 hidden lg:block">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>{isHi ? '256-बिट बैंक-ग्रेड सुरक्षा और एनक्रिप्शन' : '256-bit Bank Grade Security & Payouts'}</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-4xl font-extrabold text-white tracking-tight leading-tight">
                {isHi ? (
                  <>
                    अपने पैसों को बढ़ाएं, <br />
                    <span className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
                      GCap दैनिक रिटर्न
                    </span>{' '}
                    के साथ।
                  </>
                ) : (
                  <>
                    Grow Your Wealth With <br />
                    <span className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
                      GCap Daily Payouts
                    </span>
                  </>
                )}
              </h1>
              <p className="text-slate-400 text-sm leading-relaxed max-w-md">
                {isHi
                  ? 'स्मार्ट दैनिक ब्याज, 100% मूलधन सुरक्षा एवं 24x7 तत्काल UPI निकासी। अपने खाते में सुरक्षित लॉगिन करें।'
                  : 'Smart daily automated ROI, 100% principal return guarantee, and instant UPI withdrawals. Sign in securely to your account.'}
              </p>
            </div>

            {/* Platform Highlights */}
            <div className="grid grid-cols-2 gap-3 max-w-md pt-2">
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-emerald-400 font-bold text-lg font-mono">1.8% - 3.5%</span>
                <p className="text-xs text-slate-400 mt-0.5">{isHi ? 'दैनिक रिटर्न प्लान्स' : 'Daily ROI Rates'}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-emerald-400 font-bold text-lg font-mono">100% Refund</span>
                <p className="text-xs text-slate-400 mt-0.5">{isHi ? 'मूलधन वापसी गारंटी' : 'Capital Guarantee'}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-purple-300 font-bold text-lg font-mono">Instant UPI</span>
                <p className="text-xs text-slate-400 mt-0.5">{isHi ? '24x7 त्वरित निकासी' : 'Instant Withdrawals'}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-amber-400 font-bold text-lg font-mono">5% + 2%</span>
                <p className="text-xs text-slate-400 mt-0.5">{isHi ? '2-स्तरीय रेफरल बोनस' : '2-Tier Referral'}</p>
              </div>
            </div>

            {/* Security Guarantee Reassurance Card */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 max-w-md flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white tracking-tight">
                  {isHi ? 'प्रमाणीकृत व एनक्रिप्टेड पोर्टल' : 'Verified & Secure Portal'}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {isHi
                    ? 'सभी लॉगिन सत्र 256-बिट SSL सुरक्षा व बैंक-ग्रेड एन्क्रिप्शन द्वारा सुरक्षित हैं।'
                    : 'All account sessions are strictly protected with 256-bit bank-grade encryption.'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Login / Register Card (Full-width responsive on mobile) */}
          <div className="lg:col-span-6 w-full max-w-md mx-auto">
            <div className="bg-slate-900/90 sm:bg-slate-900/60 border border-slate-800 rounded-2xl p-4 sm:p-7 shadow-2xl shadow-black/80 backdrop-blur-md relative overflow-hidden">
              
              {/* Decorative top accent line */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-emerald-400 to-teal-400"></div>

              {/* Login vs Register Switcher */}
              <div className="flex rounded-xl bg-slate-950 p-1 mb-5 border border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('LOGIN');
                    setErrorMessage('');
                  }}
                  className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    authMode === 'LOGIN'
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {isHi ? 'लॉगिन करें (Sign In)' : 'Sign In'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('REGISTER');
                    setErrorMessage('');
                    // Ensure all registration fields are strictly blank
                    setRegName('');
                    setRegLoginId('');
                    setRegPhone('');
                    setRegEmail('');
                    setRegPassword('');
                    setRegReferral('');
                  }}
                  className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    authMode === 'REGISTER'
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {isHi ? 'नया खाता बनाएं (Sign Up)' : 'Create Account'}
                </button>
              </div>

              {/* Error Box */}
              {errorMessage && (
                <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* LOGIN FORM */}
              {authMode === 'LOGIN' ? (
                <div
                  className="space-y-4 animate-in fade-in duration-200"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleLoginSubmit(e as any);
                    }
                  }}
                >
                  {/* Login ID Input */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      {isHi ? 'मोबाइल नंबर / यूजर आईडी' : 'Mobile Number / User ID'}
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="search"
                        inputMode="text"
                        name="q_acc_code"
                        autoComplete="off"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-bwignore="true"
                        data-form-type="other"
                        aria-autocomplete="none"
                        autoCorrect="off"
                        autoCapitalize="none"
                        spellCheck={false}
                        readOnly={!isIdActive}
                        onFocus={() => setIsIdActive(true)}
                        onTouchStart={() => setIsIdActive(true)}
                        required
                        value={loginId}
                        onChange={(e) => handleLoginIdChange(e.target.value)}
                        placeholder={isHi ? 'मोबाइल नंबर या यूजर आईडी' : 'Enter Mobile Number or User ID'}
                        className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono [&::-webkit-search-cancel-button]:hidden [&::-webkit-search-decoration]:hidden"
                      />
                    </div>
                  </div>

                  {/* Password Input */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-semibold text-slate-300">
                        {isHi ? 'पासवर्ड (Password)' : 'Password'}
                      </label>
                    </div>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        type="search"
                        name="q_sec_token"
                        autoComplete="off"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-bwignore="true"
                        data-form-type="other"
                        aria-autocomplete="none"
                        autoCorrect="off"
                        autoCapitalize="none"
                        spellCheck={false}
                        readOnly={!isPassActive}
                        onFocus={() => setIsPassActive(true)}
                        onTouchStart={() => setIsPassActive(true)}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={isHi ? 'पासवर्ड दर्ज करें' : 'Enter password'}
                        style={{ WebkitTextSecurity: showPassword ? 'none' : 'disc' } as any}
                        className="w-full pl-10 pr-10 py-3 bg-slate-950 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono [&::-webkit-search-cancel-button]:hidden [&::-webkit-search-decoration]:hidden"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2">
                    {(() => {
                      const isLoginReady = Boolean(isIdValid && password.trim().length >= 4);
                      return (
                        <button
                          type="button"
                          onClick={handleLoginSubmit}
                          id="btn-submit-login"
                          /* Testing edit */
                          disabled={!isLoginReady}
                          className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition-all ${
                            isLoginReady && !isLoading
                              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-500/20 active:scale-[0.99] cursor-pointer ring-2 ring-emerald-400/50'
                              : 'bg-slate-800/90 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-60'
                          }`}>
                          {isLoading ? (
                            <span>{isHi ? 'लॉगिन हो रहा है...' : 'Logging in...'}</span>
                          ) : isLoginReady ? (
                            <>
                              <Lock className="w-4 h-4 text-slate-950" />
                              <span>{isHi ? 'लॉगिन करें (Sign In)' : 'Sign In'}</span>
                              <ArrowRight className="w-4 h-4 text-slate-950" />
                            </>
                          ) : (
                            <>
                              <Lock className="w-4 h-4 text-slate-500" />
                              <span>{isHi ? 'लॉगिन करें (आईडी व पासवर्ड डालें)' : 'Sign In (Enter ID & Password)'}</span>
                            </>
                          )}
                        </button>
                      );
                    })()}
                  </div>
                </div>
              ) : (
                /* REGISTER FORM */
                <div
                  className="space-y-3.5"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleRegisterSubmit(e as any);
                    }
                  }}
                >
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isHi ? 'पूरा नाम (Full Name)' : 'Full Name'}
                    </label>
                    <input
                      type="text"
                      inputMode="text"
                      required
                      autoComplete="one-time-code"
                      data-lpignore="true"
                      data-1p-ignore="true"
                      data-form-type="other"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder={isHi ? 'अपना पूरा नाम दर्ज करें (उदा. अमित कुमार)' : 'Enter your full name (e.g. Amit Kumar)'}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Mobile Number with Firebase Phone OTP */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold text-slate-300">
                        {isHi ? 'मोबाइल नंबर (10 अंक)' : 'Mobile Number (10 Digits)'}
                      </label>
                      {isPhoneVerified ? (
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                          <BadgeCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{isHi ? 'मोबाइल सत्यापित' : 'Phone Verified'}</span>
                        </span>
                      ) : isPhoneOtpSent ? (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full animate-pulse">
                          {isHi ? 'OTP भेजा गया' : 'OTP Sent'}
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold text-slate-400">
                          {isHi ? 'SMS OTP' : 'SMS OTP'}
                        </span>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2.5 text-xs font-mono font-bold text-slate-400 select-none">
                          +91
                        </span>
                        <input
                          type="tel"
                          inputMode="numeric"
                          required
                          disabled={isPhoneVerified}
                          autoComplete="one-time-code"
                          data-lpignore="true"
                          data-1p-ignore="true"
                          data-form-type="other"
                          value={regPhone}
                          onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9]/g, '').slice(0, 10);
                            setRegPhone(val);
                            setIsPhoneVerified(false);
                            setIsPhoneOtpSent(false);
                          }}
                          placeholder={isHi ? '10 अंकों का मोबाइल नंबर' : '10-digit mobile number'}
                          className={`w-full pl-11 pr-3.5 py-2.5 bg-slate-950 border rounded-xl text-white placeholder-slate-500 text-sm font-mono focus:outline-none transition-all ${
                            isPhoneVerified
                              ? 'border-emerald-500/60 bg-emerald-950/20 text-emerald-300 font-bold'
                              : 'border-slate-700/80 focus:border-emerald-500'
                          }`}
                        />
                      </div>

                      {!isPhoneVerified && (
                        <button
                          type="button"
                          onClick={handleSendPhoneOtp}
                          disabled={phoneOtpSending || regPhone.length < 10 || phoneResendTimer > 0}
                          className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white font-bold text-xs tracking-wide shrink-0 transition-all cursor-pointer flex items-center gap-1.5 shadow-md shadow-emerald-900/30 active:scale-95"
                          title={isHi ? 'मोबाइल पर SMS OTP भेजें' : 'Send SMS OTP'}
                        >
                          {phoneOtpSending ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Send className="w-3.5 h-3.5" />
                          )}
                          <span>
                            {phoneResendTimer > 0
                              ? `${phoneResendTimer}s`
                              : isPhoneOtpSent
                              ? (isHi ? 'दोबारा भेजें' : 'Resend')
                              : (isHi ? 'OTP भेजें' : 'Send OTP')}
                          </span>
                        </button>
                      )}
                    </div>

                    {/* Phone OTP Verification Box */}
                    {isPhoneOtpSent && !isPhoneVerified && (
                      <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                            <KeyRound className="w-3.5 h-3.5" />
                            {isHi ? 'मोबाइल पर आया 6-अंकीय OTP डालें:' : 'Enter 6-digit SMS OTP:'}
                          </span>
                          {phoneTestOtpHint && (
                            <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
                              टेस्ट OTP: {phoneTestOtpHint}
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            inputMode="numeric"
                            maxLength={6}
                            value={phoneOtp}
                            onChange={(e) => setPhoneOtp(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
                            placeholder="••••••"
                            className="flex-1 px-3 py-2 bg-slate-950 border border-emerald-500/50 rounded-xl text-white text-center font-mono font-bold tracking-widest text-base focus:outline-none focus:border-emerald-400"
                          />
                          <button
                            type="button"
                            onClick={handleVerifyPhoneOtp}
                            disabled={phoneOtpVerifying || phoneOtp.length < 4}
                            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-black text-xs rounded-xl transition-all cursor-pointer shadow-md shrink-0 active:scale-95"
                          >
                            {phoneOtpVerifying ? (isHi ? 'जांच जारी...' : 'Verifying...') : (isHi ? 'OTP वेरिफाई' : 'Verify')}
                          </button>
                        </div>
                      </div>
                    )}

                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      {isHi ? '✓ मोबाइल नंबर ही आपकी स्थायी यूजर आईडी रहेगा' : '✓ Mobile number is your permanent User ID'}
                    </span>
                  </div>

                  {/* Email (optional) */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isHi ? 'ईमेल (वैकल्पिक)' : 'Email (Optional)'}
                    </label>
                    <input
                      type="text"
                      inputMode="email"
                      autoComplete="one-time-code"
                      data-lpignore="true"
                      data-1p-ignore="true"
                      data-form-type="other"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder={isHi ? 'ईमेल पता (यदि हो तो दर्ज करें)' : 'Email address (optional)'}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Password */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {isHi ? 'नया सुरक्षित पासवर्ड' : 'Set Secure Password'}
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        autoComplete="one-time-code"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-form-type="other"
                        autoCorrect="off"
                        autoCapitalize="none"
                        spellCheck={false}
                        required
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder={isHi ? 'कम से कम 6 अक्षरों का पासवर्ड' : 'At least 6 characters'}
                        style={{ WebkitTextSecurity: showRegPassword ? 'none' : 'disc' } as any}
                        className="w-full px-3.5 pr-10 py-2.5 bg-slate-950 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegPassword(!showRegPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Govt Identity Verification (PAN & Aadhaar e-KYC Card) */}
                  <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3.5 shadow-inner">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div>
                          <h4 className="text-xs font-bold text-white">
                            {isHi ? 'सरकारी पहचान सत्यापन (PAN & Aadhaar)' : 'Govt Identity KYC (PAN & Aadhaar)'}
                          </h4>
                          <p className="text-[10px] text-slate-400">
                            {isHi ? 'सुरक्षित एवं 100% प्रमाणित फिनटेक सत्यापन' : 'Safe & verified fintech identity'}
                          </p>
                        </div>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        isPanVerified && isAadhaarVerified
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : isPanVerified || isAadhaarVerified
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}>
                        {isPanVerified && isAadhaarVerified
                          ? (isHi ? 'पूर्ण सत्यापित' : 'Fully Verified')
                          : isPanVerified || isAadhaarVerified
                          ? (isHi ? 'आंशिक' : 'Partial')
                          : (isHi ? 'लाइव सत्यापन' : 'Live KYC')}
                      </span>
                    </div>

                    {/* PAN Card Verification Input */}
                    <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                      <div className="flex items-center justify-between text-xs">
                        <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                          <span>{isHi ? 'पैन कार्ड नंबर (10 अक्षर)' : 'PAN Card (10 Characters)'}</span>
                        </label>
                        {isPanVerified ? (
                          <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                            <BadgeCheck className="w-3.5 h-3.5" />
                            {isHi ? 'पैन सत्यापित' : 'PAN Verified'}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">
                            {isHi ? 'NSDL/ITD रिकॉर्ड' : 'NSDL/ITD Live'}
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={10}
                          disabled={isPanVerified}
                          value={panNumber}
                          onChange={(e) => {
                            setPanNumber(e.target.value.toUpperCase().slice(0, 10));
                            setIsPanVerified(false);
                          }}
                          placeholder="ABCDE1234F"
                          className={`flex-1 px-3 py-2 bg-slate-900 border rounded-xl text-white font-mono text-xs uppercase tracking-wider focus:outline-none ${
                            isPanVerified
                              ? 'border-emerald-500/60 bg-emerald-950/20 text-emerald-300 font-bold'
                              : 'border-slate-700/80 focus:border-emerald-500'
                          }`}
                        />
                        {!isPanVerified && (
                          <button
                            type="button"
                            onClick={handleVerifyPan}
                            disabled={isPanVerifying || panNumber.trim().length !== 10}
                            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 hover:text-white font-bold text-xs rounded-xl border border-slate-700 transition-all cursor-pointer shrink-0 active:scale-95"
                          >
                            {isPanVerifying ? (isHi ? 'जांच जारी...' : 'Checking...') : (isHi ? 'पैन जांचें' : 'Verify PAN')}
                          </button>
                        )}
                      </div>
                      {isPanVerified && panHolderName && (
                        <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>{isHi ? `पैन धारक: ${panHolderName}` : `Holder: ${panHolderName}`}</span>
                        </p>
                      )}
                    </div>

                    {/* Aadhaar Card Verification Input */}
                    <div className="space-y-1.5 pt-2.5 border-t border-slate-800/80">
                      <div className="flex items-center justify-between text-xs">
                        <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <FileCheck className="w-3.5 h-3.5 text-blue-400" />
                          <span>{isHi ? 'आधार कार्ड नंबर (12 अंक)' : 'Aadhaar Card (12 Digits)'}</span>
                        </label>
                        {isAadhaarVerified ? (
                          <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                            <BadgeCheck className="w-3.5 h-3.5" />
                            {isHi ? 'आधार वेरिफाइड' : 'Aadhaar Verified'}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">
                            {isHi ? 'UIDAI e-KYC OTP' : 'UIDAI e-KYC OTP'}
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={14}
                          disabled={isAadhaarVerified}
                          value={aadhaarNumber}
                          onChange={(e) => {
                            const formatted = formatAadhaarNumber(e.target.value);
                            setAadhaarNumber(formatted);
                            setIsAadhaarVerified(false);
                            setIsAadhaarOtpSent(false);
                          }}
                          placeholder="XXXX XXXX XXXX"
                          className={`flex-1 px-3 py-2 bg-slate-900 border rounded-xl text-white font-mono text-xs tracking-wider focus:outline-none ${
                            isAadhaarVerified
                              ? 'border-emerald-500/60 bg-emerald-950/20 text-emerald-300 font-bold'
                              : 'border-slate-700/80 focus:border-emerald-500'
                          }`}
                        />
                        {!isAadhaarVerified && (
                          <button
                            type="button"
                            onClick={handleSendAadhaarOtp}
                            disabled={isAadhaarOtpSending || aadhaarNumber.replace(/[^0-9]/g, '').length !== 12}
                            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 hover:text-white font-bold text-xs rounded-xl border border-slate-700 transition-all cursor-pointer shrink-0 active:scale-95"
                          >
                            {isAadhaarOtpSending ? (isHi ? 'भेजा जा रहा...' : 'Sending...') : (isHi ? 'OTP भेजें' : 'Send OTP')}
                          </button>
                        )}
                      </div>

                      {/* Aadhaar OTP Input Box */}
                      {isAadhaarOtpSent && !isAadhaarVerified && (
                        <div className="mt-2 p-2.5 rounded-xl bg-blue-950/40 border border-blue-500/40 space-y-2 animate-in fade-in duration-200">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-blue-300">
                              {isHi ? 'आधार e-KYC OTP (6-अंक) दर्ज करें:' : 'Enter 6-digit Aadhaar OTP:'}
                            </span>
                            {aadhaarTestOtpHint && (
                              <span className="text-[10px] text-blue-300 font-mono bg-blue-500/20 px-2 py-0.5 rounded border border-blue-500/30">
                                टेस्ट OTP: {aadhaarTestOtpHint}
                              </span>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              maxLength={6}
                              value={aadhaarOtp}
                              onChange={(e) => setAadhaarOtp(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
                              placeholder="••••••"
                              className="flex-1 px-3 py-1.5 bg-slate-950 border border-blue-500/50 rounded-xl text-white text-center font-mono font-bold tracking-widest text-sm focus:outline-none focus:border-blue-400"
                            />
                            <button
                              type="button"
                              onClick={handleVerifyAadhaarOtp}
                              disabled={isAadhaarVerifying || aadhaarOtp.length < 4}
                              className="px-3.5 py-1.5 bg-blue-500 hover:bg-blue-400 disabled:opacity-40 text-slate-950 font-bold text-xs rounded-xl transition-all cursor-pointer shrink-0 active:scale-95"
                            >
                              {isAadhaarVerifying ? (isHi ? 'सत्यापित हो रहा...' : 'Verifying...') : (isHi ? 'वेरिफाई' : 'Verify')}
                            </button>
                          </div>
                        </div>
                      )}

                      {isAadhaarVerified && (
                        <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>{isHi ? `आधार ई-केवाईसी सत्यापित: ${maskedAadhaar}` : `Aadhaar Verified: ${maskedAadhaar}`}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Invisible Recaptcha container for Firebase Phone Auth */}
                  <div
                    id="recaptcha-phone-container"
                    style={{ position: 'fixed', bottom: 0, right: 0, width: 1, height: 1, opacity: 0, pointerEvents: 'none', zIndex: -1 }}
                  />

                  {/* Referral / Sponsor Code */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                        <span>{isHi ? 'रेफरल / स्पॉन्सर कोड' : 'Sponsor / Referral Code'}</span>
                      </label>
                      {isReferralLocked ? (
                        <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/50 flex items-center gap-1 shadow-sm">
                          <Lock className="w-3 h-3 text-amber-400" />
                          {isHi ? `स्पॉन्सर लॉक: ${regReferral}` : `Sponsor Locked: ${regReferral}`}
                        </span>
                      ) : (
                        <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded border border-emerald-500/30">
                          {isHi ? 'वैकल्पिक / डिफ़ॉल्ट' : 'Optional / Default'}
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        autoComplete="one-time-code"
                        data-lpignore="true"
                        data-1p-ignore="true"
                        data-form-type="other"
                        readOnly={isReferralLocked}
                        tabIndex={isReferralLocked ? -1 : 0}
                        value={regReferral}
                        onChange={(e) => {
                          if (!isReferralLocked) {
                            setRegReferral(e.target.value.toUpperCase());
                          }
                        }}
                        onKeyDown={(e) => {
                          if (isReferralLocked && e.key !== 'Tab' && e.key !== 'Enter') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="GCAP-DIRECT"
                        className={`w-full px-3.5 py-2.5 bg-slate-900/90 border rounded-xl font-mono text-sm uppercase font-bold pr-9 focus:outline-none transition-all ${
                          isReferralLocked
                            ? 'border-amber-500/50 text-amber-300 bg-slate-950/80 cursor-not-allowed select-none shadow-[0_0_10px_rgba(245,158,11,0.1)]'
                            : 'border-slate-700 text-white focus:border-emerald-500'
                        }`}
                      />
                      {isReferralLocked && (
                        <Lock className="w-4 h-4 text-amber-400 absolute right-3 top-2.5 pointer-events-none" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 font-sans flex items-center gap-1">
                      <span>✓</span>
                      <span>
                        {isReferralLocked
                          ? (isHi ? `🔒 स्पॉन्सर कोड (${regReferral}) आपके आमंत्रण लिंक द्वारा लॉक है (बदला नहीं जा सकता)।` : `🔒 Sponsor code (${regReferral}) is permanently locked from invite.`)
                          : (isHi ? 'यदि कोई स्पॉन्सर नहीं है तो GCAP-DIRECT रहने दें।' : 'Leave as GCAP-DIRECT if you do not have a sponsor.')}
                      </span>
                    </p>
                  </div>

                  {/* Terms Checkbox */}
                  <label className="flex items-start gap-2 text-[11px] text-slate-400 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={agreeTerms}
                      onChange={(e) => setAgreeTerms(e.target.checked)}
                      className="mt-0.5 rounded border-slate-700 text-emerald-500 focus:ring-0 bg-slate-950"
                    />
                    <span>
                      {isHi
                        ? 'मैं GCap के निवेश नियमों, 100% मूलधन सुरक्षा एवं निकासी नीतियों से सहमत हूँ।'
                        : 'I agree to GCap investment policies, 100% capital guarantee, and withdrawal terms.'}
                    </span>
                  </label>

                  {/* Submit / Login Button */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        handleRegisterSubmit(e);
                      }}
                      id="btn-submit-register"
                      aria-disabled={!isRegistrationValid || isLoading}
                      className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all mt-1 ${
                        isRegistrationValid && !isLoading
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-lg shadow-emerald-500/25 cursor-pointer active:scale-[0.99] ring-2 ring-emerald-400/50'
                          : 'bg-slate-800/90 text-slate-400 border border-slate-700/80 cursor-not-allowed opacity-75 active:scale-98'
                      }`}
                    >
                      {isLoading ? (
                        <span>{isHi ? 'सत्यापन व खाता निर्माण जारी...' : 'Creating Account & Verifying...'}</span>
                      ) : isRegistrationValid ? (
                        <>
                          <CheckCircle2 className="w-5 h-5 text-slate-950" />
                          <span>{isHi ? 'लॉगिन एवं खाता बनाएं (सत्यापित)' : 'Sign In & Create Account (Verified)'}</span>
                          <ArrowRight className="w-4 h-4 text-slate-950" />
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4 text-amber-400" />
                          <span>{isHi ? 'लॉगिन / खाता बनाएं (सत्यापन आवश्यक)' : 'Sign In (Verification Required)'}</span>
                        </>
                      )}
                    </button>

                    {/* Pending verification helper info if disabled */}
                    {!isRegistrationValid && (
                      <div className="mt-2.5 p-2.5 rounded-xl bg-slate-950/80 border border-amber-500/30 text-[11px] text-slate-400 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-400 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-amber-400" />
                            {isHi ? 'यह बटन तभी सक्रिय होगा जब ऊपर के सभी सत्यापन पूरे होंगे:' : 'Button activates only when all verifications pass:'}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${regName.trim().length >= 2 ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-slate-400 bg-slate-900/50'}`}>
                            {regName.trim().length >= 2 ? '✓' : '○'} {isHi ? 'पूरा नाम' : 'Full Name'}
                          </span>
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${isPhoneVerified ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-amber-400 bg-amber-500/10 border border-amber-500/20 font-medium'}`}>
                            {isPhoneVerified ? '✓' : '○'} {isHi ? 'मोबाइल SMS OTP' : 'SMS OTP'}
                          </span>
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${regPassword.trim().length >= 4 ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-slate-400 bg-slate-900/50'}`}>
                            {regPassword.trim().length >= 4 ? '✓' : '○'} {isHi ? 'पासवर्ड (4+ अक्षर)' : 'Password'}
                          </span>
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${isPanVerified ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-amber-400 bg-amber-500/10 border border-amber-500/20 font-medium'}`}>
                            {isPanVerified ? '✓' : '○'} {isHi ? 'पैन कार्ड (पैन जांचें)' : 'PAN Card'}
                          </span>
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${isAadhaarVerified ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-amber-400 bg-amber-500/10 border border-amber-500/20 font-medium'}`}>
                            {isAadhaarVerified ? '✓' : '○'} {isHi ? 'आधार कार्ड OTP' : 'Aadhaar OTP'}
                          </span>
                          <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${agreeTerms ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 font-semibold' : 'text-slate-400 bg-slate-900/50'}`}>
                            {agreeTerms ? '✓' : '○'} {isHi ? 'नियम व शर्तें' : 'Terms'}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Bottom Switch Hint */}
              <div className="mt-5 pt-4 border-t border-slate-800/80 text-center text-xs text-slate-400">
                {authMode === 'LOGIN' ? (
                  <p>
                    {isHi ? 'क्या आपका खाता नहीं है? ' : "Don't have an account? "}
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('REGISTER');
                        setErrorMessage('');
                      }}
                      className="text-emerald-400 hover:text-emerald-300 font-bold ml-1 cursor-pointer"
                    >
                      {isHi ? 'यहाँ रजिस्टर करें' : 'Register here'}
                    </button>
                  </p>
                ) : (
                  <p>
                    {isHi ? 'पहले से खाता है? ' : 'Already registered? '}
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('LOGIN');
                        setErrorMessage('');
                      }}
                      className="text-emerald-400 hover:text-emerald-300 font-bold ml-1 cursor-pointer"
                    >
                      {isHi ? 'लॉगिन करें' : 'Sign in'}
                    </button>
                  </p>
                )}
              </div>

            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      {viewMode !== 'android' && (
        <footer className="border-t border-slate-800/80 bg-slate-950 px-4 py-3 text-center text-xs text-slate-500">
          <p>
            © 2026 GCAP PRIVATE LIMITED • {isHi ? 'सभी अधिकार सुरक्षित' : 'All Rights Reserved'} • ISO 27001 Certified
          </p>
        </footer>
      )}
    </div>
  );
};
